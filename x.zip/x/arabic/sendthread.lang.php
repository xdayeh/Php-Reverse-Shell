<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */

$l['nav_sendthread'] = "إرسال الموضوع لصديق";

$l['send_thread'] = "أرسل لصديق";
$l['recipient'] = "المستلم :";
$l['recipient_note'] = "أدخل العنوان البريدي الخاص بصديقك هنا";
$l['subject'] = "العنوان :";
$l['message'] = "الرسالة :";
$l['image_verification'] = "صورة التأكيد";
$l['verification_subnote'] = "(حالة الاحرف)";
$l['verification_note'] = "من فضلك ادخل محتوي الصوره في المربع ادناه هذه العمليه لتأمين عمليات الاسبام ";
$l['error_nosubject'] = "يجب عليك أن تقوم بإدخال عنوان لرسالتك لإرسال هذا الموضوع لصديقك .";
$l['error_nomessage'] = "يجب أن تدخل رسالة قبل أن نرسل هذا الموضوع لصديقك .";

