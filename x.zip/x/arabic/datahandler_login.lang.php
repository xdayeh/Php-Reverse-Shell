<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */

$l['logindata_invalidpwordusername'] = 'لقد أدخلت اسم عضو / كلمة مرور خطأ. <br /><br />ان كنت نسيت كلمه المرور <a href="member.php?action=lostpw">استرجاع كلمة المرور</a>.';
$l['logindata_invalidpwordusernameemail'] = 'لقد أدخلت بريد الكتروني / باسورد خطأ. <br /><br />ان كنت نسيت كلمة المرور <a href="member.php?action=lostpw">استرجاع كلمه المرور</a>.';
$l['logindata_invalidpwordusernamecombo'] = 'لقد أدخلت كلمه مرور / بريد الكتروني او كلمة مرور / اسم العضو خطأ. <br /><br />ان كنت نسيت كلمة المرور <a href="member.php?action=lostpw">استرجاع كلمة المرور</a>.';
$l['logindata_regimageinvalid'] = 'رمز التحقق الذي أدخلته غير صحيح. من فضلك أدخل الرمز كما هو بالصوره';
$l['logindata_regimagerequired'] = 'يرجي اضافه رمز التحقق لمواصله عمليه التسجيل. من فضلك أدخل الرمز كما هو بالصوره.';
