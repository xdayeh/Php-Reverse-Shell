<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */

$l['ucp_nav_width'] = "180";
$l['ucp_nav_menu'] = "القائمة";
$l['ucp_nav_messenger'] = "الماسينجر";
$l['ucp_nav_compose'] = "رسالة جديدة";
$l['ucp_nav_tracking'] = "التتبع";
$l['ucp_nav_edit_folders'] = "تعديل المجلدات";
$l['ucp_nav_profile'] = "ملفك الشخصي";
$l['ucp_nav_edit_profile'] = "تعديل الملف الشخصي";
$l['ucp_nav_edit_options'] = "تعديل الخيارات";
$l['ucp_nav_change_email'] = "تغيير البريد";
$l['ucp_nav_change_pass'] = "تغيير كلمة المرور";
$l['ucp_nav_change_username'] = "تغيير إسم المستخدم";
$l['ucp_nav_edit_sig'] = "تعديل التوقيع";
$l['ucp_nav_change_avatar'] = "تغيير الصورة الرمزية";
$l['ucp_nav_misc'] = "خيارات إضافية";
$l['ucp_nav_editlists'] = "قائمة الأصدقاء/التجاهل";
$l['ucp_nav_favorite_threads'] = "المشاركات المفضلة";
$l['ucp_nav_subscribed_threads'] = "اشتراكات المواضيع";
$l['ucp_nav_forum_subscriptions'] = "اشتراكات الأقسام";
$l['ucp_nav_drafts'] = "المسودات المحفوظة";
$l['ucp_nav_drafts_active'] = "<strong>حفظ كمسوده ({1})</strong>";
$l['ucp_nav_notepad'] = "الملاحظات الشخصية";
$l['ucp_nav_view_profile'] = "عرض الملف الشخصي";
$l['ucp_nav_home'] = "رئيسية لوحة التحكم";
$l['ucp_nav_usergroups'] = "مجموعة الأعضاء";
$l['ucp_nav_attachments'] = "إدارة المرفقات";
