<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */



$l['all_forums'] = "كل الأقسام";
$l['forum'] = "قسم :";
$l['posted_by'] = "كتب بواسطة :";
$l['on'] = "في";
$l['portal'] = "المجله";

