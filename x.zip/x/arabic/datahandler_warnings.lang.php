<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */



$l['warnings_reached_max_warnings_day'] = 'لا يمكنك اعطاء تحذيرات لأي شخص الان لانك تعديت الحد اليومي.<br /><br />الحد الاقصي للتحذيرات التي تستطيع اعطائها باليوم {1}."';
$l['warnings_error_invalid_user'] = 'الاعضاء المختاره غير موجودين.';
$l['warnings_error_invalid_post'] = 'المشاركه المختاره غير موجوده.';
$l['warnings_error_cannot_warn_self'] = 'لا يمكنك اضافه تحذير لك.';
$l['warnings_error_user_reached_max_warning'] = 'لايمكن اضافة تحذير لهذا العضو لانه وصل بالفعل للحد الاقصي من التحذيرات.';
$l['warnings_error_no_note'] = 'لم قتم بإدخال أي ملاحظات إدارة لهذا التحذير.';
$l['warnings_error_invalid_type'] = 'نوع التحذير الذي أدخلته غير صحيح.';
$l['warnings_error_cant_custom_warn'] = 'لا يوجد لديك صلاحيه لإعطاء تحذيرات مخصصه للأعضاء.';
$l['warnings_error_no_custom_reason'] = 'لم تقم بإدخال سبب مخصص لهذا التحذير.';
$l['warnings_error_invalid_custom_points'] = 'لم تقم بإدخال رقم صحيح لعدد النقاط المضافه لهذا المستوي من التحذير. تحتاج إلي إدخال قيمه رقميه أكبر من الصفر ولكن ليس اكبر من {1}.';
$l['warnings_error_invalid_expires_period'] = 'نوع الإنتهاء الذي إدخلته غير صحيح.';
