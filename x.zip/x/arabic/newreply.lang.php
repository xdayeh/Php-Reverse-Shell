<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */



$l['nav_newreply'] = 'إضافة رد';
$l['post_reply_to'] = 'رد على {1}';
$l['post_new_reply'] = 'إضافة رد جديد';
$l['reply_to'] = 'رد على موضوع: {1}';
$l['post_subject'] = 'عنوان الرد :';
$l['your_message'] = 'محتوى الرسالة :';
$l['post_options'] = 'خيارات الرد :';
$l['options_sig'] = '<strong>التوقيع:</strong> يتضمن توقيعك. (للأعضاء فقط)';
$l['options_emailnotify'] = '<strong>التنبيه البريدي:</strong> إستلام بريد عندما يتم وضع أي ردود جديدة على الموضوع. (للأعضاء فقط)';
$l['options_disablesmilies'] = '<strong>تعطيل الإبتسامات:</strong> تعطيل ظهور الإبتسامات في ردك .';
$l['post_reply'] = 'إضافة الرد';
$l['preview_post'] = 'معاينة';
$l['mod_options'] = 'خيارات المشرفين :';
$l['close_thread'] = '<strong>إغلاق الموضوع</strong>: منع إضافة أي ردود للموضوع .';
$l['stick_thread'] = '<strong>تثبيت المشاركة:</strong> تثبيت الموضوع .';
$l['forum_rules'] = '{1} - قوانين';
$l['thread_review'] = 'عرض المشاركة (الأجدد أولا)';
$l['thread_review_more'] = 'هذا الموضوع يحتوي على أكثر من {1} رد. <a href="{2}">قراءة الموضوع كامل.</a>';
$l['posted_by'] = 'وضع بواسطة';
$l['draft_saved'] = 'تم إضافة الرد إلى المسودات بنجاح.<br />يتم تحويلك لصفحة المسودات الآن .';
$l['image_verification'] = 'صورة التأكيد';
$l['verification_note'] = 'من فضلك أدخل النص الموجود في الصورة في الحقل الموجود أسفلها. هذا الشرط لمنع سكريبتات الرد التلقائي والسبام المزعج';
$l['verification_subnote'] = '(لا يشترط تطابق الحروف الكبيرة والصغيرة)';
$l['invalid_captcha'] = 'كود الصورة الذي أدخلته غير صحيح. من فضلك أدخل الكود تماماً كما يظهر لك في الصورة .';
$l['error_post_already_submitted'] = 'عفواً, لقد قمت بوضع نفس الرد لنفس الموضوع. يمكنك تصفح الموضوع ورؤية الرد به .';
$l['multiquote_external_one'] = 'لقد حددت رد خارج عن هذا الموضوع .';
$l['multiquote_external'] = 'لقد إخترت {1} رد خارج هذا الموضوع .';
$l['multiquote_external_one_deselect'] = 'إلغاء تحديد الرد';
$l['multiquote_external_deselect'] = 'إلغاء تحديد الردود';
$l['multiquote_external_one_quote'] = 'إقتباس هذا الرد أيضاً';
$l['multiquote_external_quote'] = 'إقتباس هذه الردود أيضاً';
$l['redirect_newreply'] = 'شكراً لك, تم طرح ردك بنجاح .';
$l['redirect_newreply_moderation'] = '<br />كل الردود الجديدة تطلب مراجعة الإدارة قبل طرحها في المنتدى. سيتم نقلك للمشاركة الآن .';
$l['redirect_newreply_post'] = '<br />سوف يتم نقلك للرد الذي وضعته الآن .';
$l['redirect_newreplyerror'] = 'عفواً, لكن ردك تم رفضه قلة محتواه <br />سيتم إرجاعك للموضوع الآن .';
$l['redirect_threadclosed'] = 'لا يمكنك إضافة ردود لهذا الموضوع لأن الموضوع مغلق .';
$l['error_post_noperms'] = 'ليس لديك الصلاحية لتعديل هذه المسودة.';
$l['error_stop_forum_spam_spammer'] = 'عذرا, يبدو {1} بانه من المشتبهين فى انهم سبام ولذلك لن يتم اضافة المشاركة يرجى المحاوله لاحقا او مراسلة الادارة';
$l['error_stop_forum_spam_fetching'] = ' نعتذر حدث خطأ ما غير متوقع بقاعده بيانات الاسبام فلن يتم اضافة الرد . يرجي اعاده المحاوله لاحقا او مراسله الاداره.';
$l['error_suspendedposting'] = 'تم تعطيل رسالتك حاليا {1}.<br /><br />

تاريخ التعطيل : {2}';
$l['error_suspendedposting_temporal'] = 'حتي {1}';
$l['error_suspendedposting_permanent'] = 'نهائي';
