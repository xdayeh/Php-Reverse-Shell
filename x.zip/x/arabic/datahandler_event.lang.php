<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */

$l['eventdata_missing_name'] = 'لم تحدد إسم الحدث . من فضلك أدخل إسم للحدث  .';
$l['eventdata_missing_description'] = 'وصف الحدث لم يحدد . من فضلك أضف وصف للحدث  .';
$l['eventdata_invalid_start_date'] = 'تاريخ الحدث الذي أدخلته غير صحيح . يجب أن تتأكد أنك حددت اليوم ، الشهر و السنة بشكل صحيح . كما يجب أن تتأكد أن هذا اليوم صالح للشهر الذي حددته  .';
$l['eventdata_invalid_start_year'] = 'يمكنك إنشاء حدث للخمسة سنوات القادمة فقط . من فضلك إختر سنة صحيحة من القائمة  .';
$l['eventdata_invalid_start_month'] = 'الشهر الذي حددته لبدأ الحدث غير صحيح . من فضلك إختر شهر صحيح';
$l['eventdata_invalid_end_date'] = 'تاريخ الحدث الذي أدخلته غير صحيح . يجب أن تتأكد أنك حددت اليوم ، الشهر و السنة بشكل صحيح . كما يجب أن تتأكد أن هذا اليوم صالح للشهر الذي حددته  .';
$l['eventdata_invalid_end_year'] = 'يمكنك إنشاء حدث للخمسة سنوات القادمة فقط. من فضلك إختر سنة صحيحة من القائمة  .';
$l['eventdata_invalid_end_month'] = 'الشهر الذي حددته لنهاية الحدث غير صحيح . من فضلك إختر شهر صحيح';
$l['eventdata_invalid_end_day'] = 'يوم إنتهاء الحدث الذي حددته غير صحيح . اليوم الذي أدخلته من المحتمل أن يكون أكبر من عدد أيام هذا الشهر  .';
$l['eventdata_cant_specify_one_time'] = 'إذا قمت بتحديد تاريخ بدأ الحدث . يجب عليك تحديد تاريخ إنتهائه';
$l['eventdata_start_time_invalid'] = 'وقت البدأ الذي أدخلته غير صحيح . أمثلة على الأوقات الصحيحة كالتالي 12am, 12:01am, 00:01 .';
$l['eventdata_end_time_invalid'] = 'وقت الإنتهاء الذي أدخلته غير صحيح . أمثلة على الأوقات الصحيحة كالتالي 12am, 12:01am, 00:01 .';
$l['eventdata_invalid_timezone'] = 'التوقيت الذي حددته لهذا الحدث غير صحيح  .';
$l['eventdata_end_in_past'] = 'تاريخ الإنتهاء الذي أدخلته لحدثك هو قبل التاريخ أو الوقت الحالي  .';
$l['eventdata_only_ranged_events_repeat'] = 'الأحداث المحددة فقط (التي لها تاريخ بدأ وتاريخ إنتهاء) يمكن تكرارها  .';
$l['eventdata_invalid_repeat_day_interval'] = 'لقد أدخلت يوم خاطيء ليتم عنده التكرار  .';
$l['eventdata_invalid_repeat_week_interval'] = 'لقد أدخلت أسبوع خاطيء ليتم عنده التكرار  .';
$l['eventdata_invalid_repeat_weekly_days'] = 'لم تختار أي يوم من أيام الأسبوع لهذا الحدث  .';
$l['eventdata_invalid_repeat_month_interval'] = 'لقد أدخلت شهر خاطيء ليتم عنده التكرار . .';
$l['eventdata_invalid_repeat_year_interval'] = 'لقد أدخلت سنة خاطئة ليتم عندها التكرار . .';
$l['eventdata_event_wont_occur'] = 'إستخدام وقت البدأ والإنتهاء ليس متناسب مع إعدادات التكرار لهذا الحدث , هذا الحدث لا يمكن حدوثه  .';
$l['eventdata_no_permission_private_event'] = 'ليس لديك الصلاحيات لوضع حدث خاص  .';
