<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */



$l['nav_profile'] = 'ملف العضو {1}';
$l['nav_warning_log'] = 'سجل التحذيرات';
$l['nav_add_warning'] = 'تحذير عضو';
$l['nav_view_warning'] = 'تفاصيل التحذير';
$l['warning_for_post'] = '.. المشاركة :';
$l['already_expired'] = 'منتهي';
$l['details_username'] = 'Username';
$l['warning_active'] = 'فعال';
$l['warning_revoked'] = 'إلغاء';
$l['warning_log'] = 'سجل التحذيرات';
$l['warning'] = 'التحذير';
$l['issued_by'] = 'وضع بواسطة';
$l['date_issued'] = 'تاريخ البدأ';
$l['expiry_date'] = 'ينتهي في';
$l['active_warnings'] = 'التحذيرات الفعالة';
$l['expired_warnings'] = 'التحذيرات المنتهية';
$l['warning_points'] = '({1} النقاط)';
$l['no_warnings'] = 'هذا العضو لم يستلم أي تحذيرات من قبل. أو تم حذف جميع تحذيراته .';
$l['warn_user'] = 'تحذير عضو';
$l['post'] = 'الرد :';
$l['warning_note'] = 'ملاحظات الإدارة :';
$l['details_warning_note'] = 'ملاحظات اداريه';
$l['warning_type'] = 'نوع التحذير :';
$l['custom'] = 'سبب إضافي';
$l['reason'] = 'السبب :';
$l['points'] = 'النقاط :';
$l['details_reason'] = 'السبب';
$l['warn_user_desc'] = 'يمكنك زيادة مستوى التحذير لهذا العضو إذا كان تخطي أحد بنود وقوانين المنتدى .';
$l['send_pm'] = 'تنبيه العضو :';
$l['send_user_warning_pm'] = 'أرسل رسالة خاصة لهذا العضو لتنبيهه بخصوص هذا التحذير .';
$l['send_pm_subject'] = 'العنوان :';
$l['warning_pm_subject'] = 'لديك تحذير جديد';
$l['send_pm_message'] = 'الرسالة :';
$l['warning_pm_message'] = 'السلام عليكم عزيزي {1}

لقد تم إرسال تحذير لك بواسطة مشرفي {2}.
--

--';
$l['send_pm_options'] = 'الخيارات :';
$l['send_pm_options_anonymous'] = '<strong>رساله خاصه مجهوله</strong>: ارسال الرساله الخاصه كمجهوله المصدر.';
$l['expiration_never'] = 'دائما';
$l['expiration_hours'] = 'ساعات';
$l['expiration_days'] = 'أيام';
$l['expiration_weeks'] = 'أسابيع';
$l['expiration_months'] = 'شهور';
$l['redirect_warned_banned'] = 'تم أيضاً نقل العضو إلى مجموعة {1} بسبب {2} .';
$l['redirect_warned_suspended'] = '<br /><br />تم مع هذا المستخدم من المشاركة {1}.';
$l['redirect_warned_moderate'] = 'سوف يتم مراجعة جميع ردود هذا العضو قبل نشرها بسبب {1} .';
$l['redirect_warned_pmerror'] = '<br /><br />يرجي ملاحظه انه لم يتم ارسال الرساله الخاصه.';
$l['redirect_warned'] = 'مستوى التحذير لـ {1} تم زيادته إلى {2}%.{3}<br /><br />جاري تحويلك لآخر صفحة كنت عليها .';
$l['error_warning_system_disabled'] = 'لا يمكنك إستخدام نظام التحذيرات حيث أنه معطل بواسطة إدارة المنتدى .';
$l['error_cant_warn_group'] = 'ليس لديك الصلاحيات لتحذير أعضاء هذه المجموعة .';
$l['error_invalid_user'] = 'المستخدم الذي حددته غير صحيح.';
$l['details'] = 'التفاصيل';
$l['view'] = 'مشاهدة';
$l['current_warning_level'] = 'مستوى التحذير الحالي: <strong>{1}%</strong> ({2}/{3})';
$l['warning_details'] = 'تفاصيل التحذير';
$l['revoke_warning'] = 'إلغاء هذا التحذير';
$l['revoke_warning_desc'] = 'لإلغاء هذا التحذير من فضلك حدد السبب لهذا أدناه. هذا لن يعيد أي حظر أو إيقاف كانت ناتج عن هذا التحذير .';
$l['warning_is_revoked'] = 'تم إلغاء هذا التحذير';
$l['revoked_by'] = 'تم الإلغاء بواسطة :';
$l['date_revoked'] = 'تاريخ الإلغاء :';
$l['warning_already_revoked'] = 'هذا التحذير تم إلغائه بالفعل .';
$l['no_revoke_reason'] = 'لم تحدد سبب لرغبتك في إلغاء هذا التحذير .';
$l['redirect_warning_revoked'] = 'تم إلغاء هذا التحذير بنجاح وتقليل عدد نقاط التحذير لهذا المستخدم.<br /><br />جاري تحويلك لصفحة التحذيرات والتنبيهات .';
$l['result'] = 'الناتج:';
$l['result_banned'] = 'سوف يتم نقل العضو لمجموعة المحظورين ({1}) {2}';
$l['result_suspended'] = 'سوف يتم إيقاف مشاركات {1}';
$l['result_moderated'] = 'سوف يتم جعل المشاركات تحت مراجعة الإدارة {1}';
$l['result_period'] = '{1} {2}';
$l['result_period_perm'] = 'دائما';
$l['hour_or_hours'] = 'ساعة/ساعات';
$l['day_or_days'] = 'يوم/أيام';
$l['week_or_weeks'] = 'أسبوع/أسابيع';
$l['month_or_months'] = 'شهر/شهور';
$l['expires'] = 'ينتهي في :';
$l['new_warning_level'] = 'مستوى تحذير جديد :';
$l['error_cant_warn_user'] = 'ليس لديك الصلاحيات لتحذير هذا العضو .';
$l['existing_post_warnings'] = 'التحذيرات الموجودة لهذه المشاركة';
