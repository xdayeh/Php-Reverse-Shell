<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */



$l['forum'] = "قسم :";
$l['printable_version'] = "نسخة قابلة للطباعة";
$l['pages'] = "الصفحات:";
$l['thread'] = "الموضوع :";
