<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */



$l['nav_announcements'] = 'إعلانات المنتدى';

$l['announcements'] = 'إعلان';

$l['forum_announcement'] = 'إعلان المنتدى : {1}';

$l['error_invalidannouncement'] = 'الإعلان الذي حددته خاطيء  .';

$l['announcement_edit'] = 'تعديل';

$l['announcement_qdelete'] = 'حذف';

$l['announcement_quickdelete_confirm'] = 'متأكد من رغبتك في حذف هذا الإعلان؟';
