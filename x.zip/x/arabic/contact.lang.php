<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */



$l['contact'] = 'اتصل بنا';
$l['contact_no_message'] = 'لم تقم بكتابه رساله لأرسالها';
$l['contact_no_subject'] = 'يجب إدخال عنوان للرساله';
$l['contact_no_email'] = 'يجب إدخال بريد إلكتروني صحيح';
$l['contact_success_message'] = 'تم إرسال رسالتك للإداره بنجاح.';
$l['contact_subject'] = 'العنوان';
$l['contact_subject_desc'] = 'عنوان موضوع الرساله.';
$l['contact_message'] = 'الرساله';
$l['contact_message_desc'] = 'تفاصيل الرساله المراد إرسالها.';
$l['contact_email'] = 'البريد الإلكتروني';
$l['contact_email_desc'] = 'إدخل بريدك الالكتروني للإستلام الرد عليه.';
$l['contact_send'] = 'إرسال';
$l['image_verification'] = 'صورة التحقق';
$l['verification_note'] = 'قم بإدخال محتوي الصوره للتحقق من عمليه الارسال والحمايه من الارسال التلقائي';
$l['verification_subnote'] = '(حالة الأحرف)';
$l['invalid_captcha'] = 'رمز التحقق الذي أدخلته غير صحيح. برجاء أدخال الرمز كما يظهر بالظهور.';
$l['subject_too_long'] = 'عنوان الرساله طويل. يجب ان يكون أقصر من {1} حرف (العدد حاليا  {2}).';
$l['message_too_short'] = 'الرساله قصيره جدا. يجب ان تكون الرساله اطول من  {1} حرف (العدد حاليا {2}).';
$l['message_too_long'] = 'الرساله طويله جدا. يجب ان يكون اقل من  {1} حرف (العدد حاليا {2}).';
$l['error_stop_forum_spam_spammer'] = 'نعتذر, {1} يطابق قائمة السبامر المحظورين من الارسال لذلك تم حظر الاتصال.';
$l['error_stop_forum_spam_fetching'] = 'نعتذر, حدث خطأ في التأكد من رسالتك مع قاعدة بيانات المحظورين  يرجي إعادة المحاوله في وقتا لاحق.';
