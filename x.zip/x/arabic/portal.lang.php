<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */

$l['nav_portal'] = "المدونة";
$l['posted_by'] = "بواسطة :";
$l['forum'] = "المنتدي :";
$l['replies'] = "التعليقات";
$l['no_replies'] = "لا يوجد تعليقات";
$l['latest_threads'] = "آخر المواضيع";
$l['latest_threads_replies'] = "التعليقات :";
$l['latest_threads_views'] = "المشاهدات :";
$l['latest_threads_lastpost'] = "آخر تعليق بواسطة :";
$l['private_messages'] = "الرسائل الخاصة";
$l['pms_received_new'] = "{1}, لديك <b>{2}</b> رسالة/رسائل غير مقروءة .";
$l['pms_unread'] = "غير مقروءة";
$l['pms_total'] = "إجمالي الرسائل";
$l['search_forums'] = "البحث في المنتدى";
$l['advanced_search'] = "البحث المتقدم";
$l['forum_stats'] = "إحصائية المنتدى";
$l['num_members'] = "الأعضاء :";
$l['latest_member'] = "آخر عضو :";
$l['num_threads'] = "مواضيع المنتدى :";
$l['num_posts'] = "مشاركات المنتدى :";
$l['full_stats'] = "الإحصائية الكاملة";
$l['welcome'] = "أهلاً بك , {1}";
$l['guest'] = "ضيف";
$l['guest_welcome_registration'] = "يجب عليك <a href=\"{1}\">التسجيل</a> حتى تتمكن من المشاركة في المنتدى .";
$l['username'] = "إسم المستخدم";
$l['password'] = "كلمة المرور";
$l['login'] = "دخول!";
$l['member_welcome_lastvisit'] = "آخر زيارة :";
$l['since_then'] = "الجديد منذ آخر زيارة لك :";
$l['new_announcements'] = "{1} إعلان جديد";
$l['new_announcement'] = "إعلان جديد";
$l['new_threads'] = "{1} موضوع جديد";
$l['new_thread'] = "موضوع جديد";
$l['new_posts'] = "{1} رد جديد";
$l['new_post'] = "رد جديد";
$l['view_new'] = "مشاهدة المشاركات الجديدة";
$l['view_todays'] = "عرض مشاركات اليوم";
$l['online'] = "المتواجدون الآن";
$l['online_user'] = "يوجد مستخدم واحد متصل";
$l['online_users'] = "يوجد حالياً <b>{1}</b> مستخدم .";
$l['online_counts'] = "<b>{1}</b> عضو | <b>{2}</b> ضيف";
$l['print_this_item'] = "طباعة هذا الجزء";
$l['send_to_friend'] = "إرسال هذا الجزء لصديق";
$l['latest_announcements'] = "احدث الاعلانات";
$l['portal_disabled'] = "لا يمكنك استخدام المجله حيث تم اغلاقها من الاداره.";
