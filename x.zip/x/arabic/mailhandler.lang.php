<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */



$l['error_no_connection'] = 'حدث خطأ أثناء محاولة الإتصال من خلال السيرفر: ';
$l['error_no_message'] = 'لم يتم تحديد أي رسالة .';
$l['error_no_subject'] = 'لم يتم وضع عنوان .';
$l['error_no_recipient'] = 'لم يتم تحديد مستقبل الرسالة .';
$l['error_not_sent'] = 'حدث خلل أثناء محاولة إرسال البريد عبر المنتدى .';
$l['error_status_missmatch'] = 'حالة السيرفر لا تتوافق مع النتائج المتوقعة, ينتج عنها: ';
$l['error_data_not_sent'] = 'لم يتم إرسال البيانات إلى سيرفر: ';
$l['error_occurred'] = 'هناك خطأ ما حدث. من فضلك أصلح الأخطاء التالية للمتابعة.<br />';
