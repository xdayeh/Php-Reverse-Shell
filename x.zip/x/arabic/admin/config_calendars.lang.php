<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['calendars'] = "التقويمات";
$l['manage_calendars'] = "إدارة التقويمات";
$l['manage_calendars_desc'] = "هذا الجزء للتحكم وإدارة التقويمات الخاصة في منتداك. إذا قمت بتغيير ترتيب العرض لتقويم أو أكثر, تأكد أنك اعتمدت التغييرات بالنقر على الزر أسفل الصفحة.";
$l['add_calendar'] = "إضافة تقويم جديد";
$l['add_calendar_desc'] = "يمكنك هنا إضافة تقويم جديد.";
$l['edit_calendar'] = "تعديل التقويم";
$l['edit_calendar_desc'] = "لتعديل تقويم تم إنشائه مسبقاً";

$l['calendar'] = "التقويم";
$l['order'] = "الترتيب";
$l['no_calendars'] = "لا يوجد تقويمات في منتداك في الوقت الحالي.";
$l['save_calendar_orders'] = "حفظ ترتيب عرض التقويم.";

$l['name'] = "الإسم";
$l['display_order'] = "ترتيب العرض.";
$l['week_start'] = "يوم بدأ الأسبوع";
$l['week_start_desc'] = "قم بإعداد اليوم الذي يبدأ به الأسبوع في هذا التقويم";
$l['sunday'] = "الأحد";
$l['monday'] = "الأثنين";
$l['tuesday'] = "الثلاثاء";
$l['wednesday'] = "الأربعاء";
$l['thursday'] = "الخميس";
$l['friday'] = "الجمعة";
$l['saturday'] = "السبت";
$l['event_limit'] = "تحديد الحدث";
$l['event_limit_desc'] = "عدد الأحداث التي تعرض. قبل أن يتم وضع رابط يوجه لبقية الأحداث بدلاً من عرضهم بنفس الصفحة";
$l['show_birthdays'] = "عرض تواريخ الميلاد ؟";
$l['show_birthdays_desc'] = "هل تريد عرض تواريخ ميلاد المسجلين بتقويم المنتدى ؟";
$l['moderate_events'] = "إدارة الأحداث الجديدة ؟";
$l['moderate_events_desc'] = "إذا جعلت هذا الإختيار 'نعم,' كل الأحداث التي تنشأ بواسطة الأعضاء سوف تكون 'في إنتظار مراجعة المشرفين' معدة حسب صلاحيات تقويمهم.";
$l['allow_html'] = "السماح بأكواد HTML في الأحداث ؟";
$l['allow_mycode'] = "السماح بأكواد المنتدى في الأحداث ؟";
$l['allow_img'] = "السماح بكود [IMG] الخاص بالصور في الأحداث ؟";
$l['allow_video'] = "السماح بكود الفيديو في الأحداث؟";
$l['allow_smilies'] = "السماح بالإبتسامات في الأحداث ؟";
$l['save_calendar'] = "حفظ التقويم";

$l['permissions'] = "الصلاحيات";
$l['edit_permissions'] = "تعديل صلاحيات التقويم";
$l['calendar_permissions_for'] = "تعديلا صلاحيات تقويم لـ";
$l['permissions_group'] = "مجموعة";
$l['permissions_view'] = "مشاهدة";
$l['permissions_post_events'] = "إضافة أحداث";
$l['permissions_bypass_moderation'] = "إنتظار مراجعة الإدارة";
$l['permissions_moderator'] = "صلاحيات المشرفين";
$l['permissions_all'] = "الكل ؟";
$l['permissions_use_group_default'] = "إستخدام إفتراضي المجموعة";
$l['save_permissions'] = "حفظ الصلاحيات";

$l['error_invalid_calendar'] = "التقويم الذي حددته غير موجود.";
$l['error_missing_name'] = "لم تدخل إسم للتقويم.";
$l['error_missing_order'] = "لم تدخل ترتيب عرض التقويم.";

$l['success_calendar_created'] = "تم إضافة التقويم بنجاح";
$l['success_calendar_updated'] = "تم تعديل التقويم بنجاح";
$l['success_calendar_permissions_updated'] = "تم تحديث صلاحيات التقويم بنجاح";
$l['success_calendar_deleted'] = "تم حذف التقويم بنجاح";
$l['success_calendar_orders_updated'] = "تم تحديث ترتيب عرض التقويم بنجاح";
$l['confirm_calendar_deletion'] = "متأكد من رغبتك في حذف التقويم ؟";

