<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['smilies'] = "الإبتسامات";
$l['manage_smilies'] = "إدارة الإبتسامات";
$l['manage_smilies_desc'] = "لتعديل وحذف وإدارة الإبتسامات";
$l['add_smilie'] = "إضافة إبتسامة جديدة";
$l['add_smilie_desc'] = "لإضافة وجه معبر (إبتسامة) جديد";
$l['add_multiple_smilies'] = "إضافة عدة إبتسامات";
$l['add_multiple_smilies_desc'] = "لإضافة مجموعة إبتسامات على دفعة واحدة.";
$l['edit_smilie'] = "تعديل إبتسامة";
$l['edit_smilie_desc'] = "لتعديل إبتسامة";
$l['mass_edit'] = "تعديل جماعي";
$l['mass_edit_desc'] = "لتعديل كل الإبتسامات التي لديك دفعة واحدة.";

$l['no_smilies'] = "لا يوجد إبتسامات في منتداك حالياً.";

$l['image'] = "الصورة";
$l['name'] = "الإسم";
$l['text_replace'] = "نص الإستبدال";
$l['text_replace_desc'] = "هذا هو النص الذي سيتم استبداله بابتسامه يرجي وضع نص واحد في السطر";
$l['image_path'] = "مسار الصورة";
$l['image_path_desc'] = "مسار صورة الإبتسامة";
$l['order'] = "الترتيب";
$l['display_order'] = "ترتيب العرض";
$l['display_order_desc'] = "ترتيب عرض الإبتسامة بين قائمة الإبتسامات. هذا الرقم لا يجب أن يكون مثل رقم أي إبتسامة أخرى.";
$l['mass_edit_show_clickable'] = "عرضها مع الإبتسامات القابلة للضغط ؟";
$l['show_clickable'] = "عرضها مع قائمة الإبتسامات القابلة للضغط ؟";
$l['show_clickable_desc'] = "هل تريد عرض الإبتسامة في قائمة الإبتسامات القابلة للضغط بمحرر المشاركات ؟";
$l['include'] = "أضف ؟";
$l['path_to_images'] = "مسار الصور";
$l['path_to_images_desc'] = "مسار مجلد صور الإبتسامات الذي تريد إضافتها";
$l['smilie_delete'] = "حذف ؟";
$l['save_smilie'] = "حفظ الإبتسامة";
$l['save_smilies'] = "حفظ الإبتسامات";
$l['show_smilies'] = "عرض الإبتسامات";
$l['reset'] = "تفريغ";

$l['error_missing_name'] = "لم تقم بإدخال إسم لهذه الإبتسامة";
$l['error_missing_text_replacement'] = "لم تقم بتحديد نص الإستبدال لهذا الإبتسامة";
$l['error_missing_path'] = "لم تقم بإدخال مسار صورة الإبتسامة.";
$l['error_missing_path_multiple'] = "لم تقم بإدخال المسار";
$l['error_missing_order'] = "لم تقم بتحديد ترتيب عرض هذه الإبتسامة";
$l['error_duplicate_order'] = "لم تقم بتجديد ترتيب عرض صحيح لهذه الابتسامات";
$l['error_missing_clickable'] = "لم تقم بإختيار \"نعم\" أو \"لا\" امام إختيار \"عرضها مع الإبتسامات القابلة للضغط ؟\"";
$l['error_no_smilies'] = "لا يوجد إبتسامات في المجلد الذي حددته, أو أن كل الإبتسامات الموجودة بالمجلد الذي حددته تم إضافتها مسبقاً.";
$l['error_no_images'] = "لا يوجد صور في المجلد الذي حددته.";
$l['error_none_included'] = "لم تقم بإختيار أي إبتسامات لضمها.";
$l['error_invalid_path'] = "لم تقم بإدخال مسار صحيح";
$l['error_invalid_smilie'] = "الإبتسامة التي حددتها غير موجودة.";

$l['success_smilie_added'] = "تم إضافة الإبتسامة بنجاح.";
$l['success_multiple_smilies_added'] = "تم إضافة الإبتسامات التي حددتها بنجاح";
$l['success_smilie_updated'] = "تم تحديث الإبتسامة بنجاح.";
$l['success_multiple_smilies_updated'] = "تم تحديث الإبتسامات بنجاح.";
$l['success_smilie_deleted'] = "تم حذف الإبتسامات التي حددتها بنجاح.";
$l['success_mass_edit_updated'] = "تم تحديث الإبتسامات بنجاح";

$l['confirm_smilie_deletion'] = "متأكد من رغبتك في حذف الإبتسامة ؟";

