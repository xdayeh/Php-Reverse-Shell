<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

// Tabs
$l['banning'] = "الحظر";
$l['banned_accounts'] = "الأعضاء المحظورين";
$l['banned_accounts_desc'] = "لإدارة الأعضاء الذين تم حظرهم من دخول منتداك.";
$l['ban_a_user'] = "حظر عضو";
$l['ban_a_user_desc'] = "لإضافة عضو لقائمة الأعضاء المحظورين.";
$l['edit_ban'] = "تعديل الحظر";
$l['edit_ban_desc'] = "لتعديل فترة الحظر, وسبب الحظر للمستخدمين الذي تم حظرهم.";
$l['banned_ips'] = "عناوين الآي بي المحظورة.";
$l['disallowed_usernames'] = "منع أسماء مستخدمين";
$l['disallowed_email_addresses'] = "منع عناوين بريدية";

// Errors
$l['error_invalid_ban'] = "لقد إخترت حظر خاطيء للتعديل.";
$l['error_invalid_username'] = "إسم المستخدم الذي أدخلته خاطيء أو غير موجود.";
$l['error_no_perm_to_ban'] = "ليس لديك التصاريح لحظر هذا العضو.";
$l['error_already_banned'] = "هذا العضو موجود بمجموعة الحظر بالفعل, ولا يمكن إضافته مرة أخرى.";
$l['error_ban_self'] = "لا يمكنك حظر عضويتك.";
$l['error_no_reason'] = "لم تقم بإدخال سبب حظر هذا العضو.";

// Success
$l['success_ban_lifted'] = "تم رفع الحظر بنجاح.";
$l['success_banned'] = "تم حظر العضو بنجاح.";
$l['success_ban_updated'] = "تم تحديث الحظر بنجاح.";
$l['success_pruned'] = "تم تنظيف مشاركات ومواضيع المستخدم الذي حددته.";

// Confirm
$l['confirm_lift_ban'] = "متأكد من رغبتك في رفع هذا الحظر ؟";
$l['confirm_prune'] = "متأكد انك تريد تنظيف المشاركات والمواضيع التي كتبها هذا المستخدم؟";

//== Pages
//= Add / Edit
$l['ban_username'] = "إسم المستخدم <em>*</em>";
$l['autocomplete_enabled'] = "الإنتهاء التلقائي مفعـّل في هذا الحقل.";
$l['ban_reason'] = "سبب الحظر";
$l['ban_group'] = "مجموعة المحظورين <em>*</em>";
$l['ban_group_desc'] = "لحظر هذا العضو يجب أن يتم نقله لمجموعة المحظورين.";
$l['ban_time'] = "فترة الحظر <em>*</em>";

//= Index
$l['user'] = "المستخدم";
$l['moderation'] = "الإشراف";
$l['ban_lifts_on'] = "يرفع الحظر في";
$l['time_left'] = "الوقت المتبقي";
$l['permenantly'] = "نهائي";
$l['na'] = "لا يوجد";
$l['for'] = "لـ";
$l['bannedby_x_on_x'] = "<strong>{1}</strong><br /><small>تم الحظر بواسطة {2} في {3} {4}</small>";
$l['lift'] = "رفع";
$l['no_banned_users'] = "لا يوجد لديك أعضاء محظورين حالياً .";
$l['prune_threads_and_posts'] = "حذف المشاركات والمواضيع";

// Buttons
$l['ban_user'] = "حظر العضو";
$l['update_ban'] = "تحديث الحظر";
$l['search_user'] = 'بحث العضو';

