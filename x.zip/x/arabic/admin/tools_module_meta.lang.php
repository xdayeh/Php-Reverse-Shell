<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['tools_and_maintenance'] = "الأدوات و الصيانة";

$l['maintenance'] = "الصيانة";
$l['logs'] = "السجلات";

$l['system_health'] = "كفاءة النظام";
$l['cache_manager'] = "إدارة الملفات التخزينية Cache";
$l['task_manager'] = "إدارة المهام";
$l['recount_and_rebuild'] = "إعادة العد و إعادة البناء";
$l['view_php_info'] = "معلومات الـ PHP";
$l['database_backups'] = "نُسَخ قاعدة البيانات";
$l['optimize_database'] = "تحسين قاعدة البيانات";
$l['file_verification'] = "فحص الملفات";

$l['administrator_log'] = "سِجل الإداريين";
$l['moderator_log'] = "سجل المشرفين";
$l['user_email_log'] = "سجل الإستخدام البريدي";
$l['system_mail_log'] = "سجل نظام البريد";
$l['user_warning_log'] = "سجل مستخدم التحذيرات";
$l['spam_log'] = "سجل الاسبام";
$l['statistics'] = "الإحصائيات";

$l['can_access_system_health'] = "يمكنه الوصول لكفاءة النظام ؟";
$l['can_manage_cache'] = "يمكنه الوصول لإدارة الملفات التخزينية الـ Cache  ؟";
$l['can_manage_tasks'] = "يمكنه الوصول للمهام المجدولة ؟";
$l['can_manage_db_backup'] = "يمكنه إدارة النسخ الإحتياطي ؟";
$l['can_optimize_db'] = "يمكنه تحسين قاعدة البيانات ؟";
$l['can_recount_and_rebuild'] = "يمكنه إعادة العد و إعادة البناء ؟";
$l['can_manage_admin_logs'] = "يمكنه إدارة سجل الإداريين ؟";
$l['can_manage_mod_logs'] = "يمكنه إدارة سجل المشرفين ؟";
$l['can_manage_user_mail_log'] = "يمكنه إدارة سجل مُستخدِم البريد ؟";
$l['can_manage_system_mail_log'] = "يمكنه إدارة سجل نظام البريد ؟";
$l['can_manage_user_warning_log'] = "يمكنه إدارة سجل مستخدم التحذيرات ؟";
$l['can_manage_spam_log'] = "يمكنه إدارة سجل الاسبام";
$l['can_view_php_info'] = "يمكنه مشاهدة معلومات الـ PHP ؟";
$l['can_manage_file_verification'] = "يمكنه إدارة فحص الملفات؟";
$l['can_view_statistics'] = "يمكنه مشاهدة الإحصائيات؟";


