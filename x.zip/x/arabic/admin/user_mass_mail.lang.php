<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['mass_mail'] = "البريد الجماعي";

$l['mass_mail_queue'] = "البريد الجماعي المحفوظ";
$l['mass_mail_queue_desc'] = "لإدارة البريد الجماعي الذي تم إرساله, أو المحفوظ للإستخدام في المستقبل.";
$l['create_mass_mail'] = "إنشاء بريد جديد";
$l['create_mass_mail_desc'] = "لإنشاء بريد جماعي جديد وإعداد خصائصه.";
$l['mass_mail_archive'] = "أرشيف البريد الجماعي";
$l['mass_mail_archive_desc'] = "لمشاهدة سجلات البريد الجماعي التي تم إرسالها بالفعل.";
$l['edit_mass_mail'] = "تعديل البريد الجماعي";
$l['edit_mass_mail_desc'] = "لتعديل خيارات البريد الجماعي.";
$l['send_mass_mail'] = "إرسال البريد الجماعي";

$l['email_addr'] = "عنوان البريد";
$l['board_name'] = "إسم المنتدى";
$l['board_url'] = "رابط المنتدى";
$l['personalize_message'] = "تخصيص هذه الرسالة:";

$l['message_settings'] = "إعدادات الرسالة";
$l['subject'] = "العنوان";
$l['subject_desc'] = "من فضلك أدخل عنوان الرسالة.";
$l['send_via_email'] = "الإرسال بواسطة البريد";
$l['send_via_pm'] = "الإرسال بواسطة رسالة خاصة";
$l['message_type'] = "نوع الرسالة";
$l['deliver_immediately'] = "التوصيل في الحال";
$l['deliver_specific'] = "التوصيل في تاريخ محدد";
$l['delivery_date'] = "تاريخ التوصيل";
$l['delivery_date_desc'] = "من فضلك أدخل التاريخ الذي تريد هذا البريد الجماعي أن يصل فيه.";
$l['per_page'] = "بكل صفحة";
$l['per_page_desc'] = "من فضلك أدخل عدد الرسائل الجماعية لكل صفحة.";
$l['plain_text_only'] = "نصي فقط";
$l['html_only'] = "HTML فقط";
$l['html_and_plain_text'] = "HTML ونصي";
$l['message_format'] = "هيئة الرسالة";
$l['define_html_message'] = "عرف رسالة الـ HTML";
$l['define_html_message_desc'] = "إدخل نسخة الـ HTML للرسالة";
$l['auto_gen_plain_text'] = "قم بإنشاء النسخة النصية تلقائياً";
$l['define_text_version'] = "عرف النسخة النصية";
$l['define_text_version_desc'] = "أدخل النسخة النصية من هذه الرسالة";
$l['define_the_recipients'] = "عرف المستلمين";
$l['username_contains'] = "إسم المستخدم يحتوي على...";
$l['email_addr_contains'] = "العنوان البريدي يحتوي على...";
$l['members_of'] = "أعضاء في المجموعات التالية...";
$l['greater_than'] = "أكثر من";
$l['is_exactly'] = "تماماً";
$l['less_than'] = "أقل من";
$l['more_than'] = "أكثر من";
$l['post_count_is'] = "عدد المشاركات هو";
$l['hours'] = "ساعات";
$l['days'] = "أيام";
$l['weeks'] = "أسابيع";
$l['months'] = "شهور";
$l['years'] = "سنين";
$l['ago'] = "قبل";
$l['user_last_active'] = "اخر نشاط للمستخدم";
$l['user_registered'] = "عضو مسجل";
$l['save_mass_mail'] = "حفظ البريد الجماعي";

$l['step_four'] = "الخطوة 4";
$l['delivery_method'] = "عملية التوصيل";
$l['private_message'] = "رسالة خاصة";
$l['email'] = "بريد";
$l['subject'] = "العنوان";
$l['message'] = "الرسالة";
$l['text_based'] = "مبنية على نص";
$l['preview'] = "معاينة";
$l['mass_mail_preview'] = "معاينة البريد المتعدد";
$l['html_based'] = "مبنية على HTML";
$l['total_recipients'] = "إجمالي المستلمين";
$l['change_recipient_conds'] = "تغيير شروط الإستلام";
$l['review_message'] = "معاينة الرسالة";
$l['define_delivery_date'] = "عرف تاريخ التوصيل";
$l['schedule_for_delivery'] = "الجدولة للتوصيل";
$l['username'] = "إسم المستخدم";

$l['step_three'] = "الخطوة 3";
$l['next_step'] = "الخطوة التالية";

$l['step_two'] = "الخطوة 2";
$l['review_text_version'] = "معاينة النسخة النصية";
$l['review_text_version_desc'] = "من فضلك قم بمعاينة النسخة النصية التي تم إنشاؤها";

$l['step_one'] = "الخطوة 1";

$l['status'] = "الحالة";
$l['recipients'] = "المستلمين";
$l['delivered'] = "تم التوصيل";
$l['canceled'] = "تم الإلغاء";
$l['resend'] = "أعد الإرسال";
$l['no_archived_messages'] = "لا يوجد لديك أي رسائل جماعية تم إرسالها أو إلغاؤها";

$l['draft'] = "المسودات";
$l['queued'] = "المنتظرة";
$l['delivering'] = "يتم التوصيل";
$l['na'] = "لا يوجد";
$l['mass_mail_cancel_confirmation'] = "متأكد من رغبتك في إلغاء توصيل هذا البريد الجماعي ؟";
$l['no_unsent_messages'] = "ليس لديك أي رسائل جماعية, لم يتم إرسالها, معلقة, أو يتم توصيلها حالياً.";

$l['error_invalid_mid'] = "لقد حددت مراسلة جماعية خاطئة.";
$l['error_only_in_future'] = "يمكنك فقط توصيل الرسائل الجماعية في المستقبل.";
$l['error_no_users'] = "معايير البحث التي حددتها لا تتوافق مع أي مستخدمين لديك. من فضلك أعد تعيين المعايير وحاول مرة أخرى.";
$l['error_missing_plain_text'] = "لم تقم بإدخال نسخة نصية لهذه الرسالة.";
$l['error_missing_subject'] = "لم تقم بإدخال عنوان هذه الرسالة الجماعية.";
$l['error_missing_message'] = "لم تقم بكتابة رسالتك الجماعية.";
$l['error_missing_html'] = "لم تقم بإدخال نسخة الـ HTML لهذه الرسالة الجماعية.";
$l['error_delete_invalid_mid'] = "لقد حددت بريد جماعي خاطيء للحذف.";

$l['success_mass_mail_saved'] = "تم حفظ البريد الجماعي بنجاح.";
$l['success_mass_mail_deleted'] = "تم حذف البريد الجماعي الذي حددته بنجاح.";
$l['success_mass_mail_resent'] = "تم نسخ البريد الجماعي بنجاح. من فضلك قم بالمعاينة أدناه.";
$l['success_mass_mail_canceled'] = "تم إلغاء البريد الجماعي بنجاح.";

$l['mass_mail_deletion_confirmation'] = "متأكد من رغبتك في حذف هذا البريد الجماعي ؟";

