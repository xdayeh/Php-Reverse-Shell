<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['forum_announcements'] = "إعلانات المنتدى";
$l['forum_announcements_desc'] = "لإدارة إعلانات منتداك. إعلانات عامة تظهر بجميع الأقسام, أو إعلانات تظهر داخل جميع أقسام تصنيف ما, أو إعلانات تظهر داخل قسم واحد فقط.";
$l['add_announcement'] = "إضافة إعلان";
$l['add_announcement_desc'] = "لإضافة إعلان لقسم واحد أو كل الأقسام.";
$l['update_announcement'] = "حفظ الإعلان";
$l['preview_announcement'] = "مشاهدة الاعلان";
$l['update_announcement_desc'] = "لتحديث تفاصيل الإعلان.";

$l['start_date_desc'] = "خلال هذا الوقت والتاريخ (بتوقيت جرينيتش) سيظهر هذا الإعلان في القسم/الأقسام المحددة.";
$l['end_date_desc'] = "خلال هذا الوقت والتاريخ (بتوقيت جرينيتش) سوف يكون هذا الإعلان غير مرئي. يمكنك إختيار \"غير محدد\" لجعل الإعلان لا يظهر بأقسام منتداك حتى تقوم بحذفه أو التعديل عليه.";
$l['forums_to_appear_in_desc'] = "سيظهر الإعلان في الأقسام التي إخترتها أدناه, وسيظهر الإعلان في الأقسام التي إخترتها وكل الأقسام الفرعية منها.";

$l['announcement'] = "إعلان";
$l['global_announcements'] = "إعلانات عامة";

$l['no_global_announcements'] = "لا يوجد إعلانات عامة في منتداك حالياً";
$l['no_forums'] = "لا يوجد حالياً إعدادات للأقسام لعرض إعلانات المنتدى.";

$l['confirm_announcement_deletion'] = "متأكد من رغبتك في حذف هذا الإعلان ؟";

$l['success_announcement_deleted'] = "تم حذف الإعلان الذي حددته بنجاح.";
$l['success_added_announcement'] = "تم إضافة الإعلان بنجاح.";
$l['success_updated_announcement'] = "تم تحديث الإعلان بنجاح.";

$l['error_invalid_announcement'] = "من فضلك أدخل إعلان صحيح.";
$l['error_missing_title'] = "لم تقم بتحديد عنوان للإعلان.";
$l['error_missing_message'] = "لم تدخل محتوى الإعلان.";
$l['error_missing_forum'] = "لم تقم بإختيار قسم لعرض الإعلان به.";
$l['error_invalid_start_date'] = "خطا في تاريخ بدأ الاعلان.";
$l['error_invalid_end_date'] = "خطأ في تاريخ نهاية الاعلان.";
$l['error_end_before_start'] = "تاريخ نهايه الاعلان يجب ان تكون بعد تاريخ بدأ الأعلان.";

$l['add_an_announcement'] = "أضف إعلان";
$l['update_an_announcement'] = "تحديث إعلان";
$l['save_announcement'] = "حفظ الإعلان";
$l['title'] = "العنوان";
$l['start_date'] = "تاريخ البدأ";
$l['end_date'] = "تاريخ الإنتهاء";
$l['message'] = "الرسالة";
$l['forums_to_appear_in'] = "أقسام يظهر بها";
$l['allow_html'] = "السماح بأكواد HTML  ؟";
$l['allow_mycode'] = "السماح بأكواد المنتدى ؟";
$l['allow_smilies'] = "السماح بالإبتسامات ؟";
$l['time'] = "الوقت:";
$l['set_time'] = "إعداد الوقت";

$l['announcement_preview'] = 'معاينه الاعلان';

