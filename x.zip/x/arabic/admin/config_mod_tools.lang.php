<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['mod_tools'] = "أدوات المشرفين";

$l['thread_tools'] = "أدوات المواضيع";
$l['thread_tools_desc'] = "أدوات إضافية للمشرفين. تمكنك هذه الخاصية من إضافة أداة جديدة للمشرفين. يمكنهم إستخدامها لكل من المواضيع والردود. هذه الأدوات يمكن أن تستخدم مثل الأدوات الإفتراضية التي تظهر للمشرفين والإداريين في منتداك. ويمكنك هنا إدارة أدوات المواضيع.";

$l['add_thread_tool'] = "إضافة أداة للمواضيع";
$l['add_new_thread_tool'] = "إضافة أداة لكتابة المواضيع.";
$l['add_thread_tool_desc'] = "يمكنك إضافة أداة اشرافية جديدة للمواضيع. هذه الأداة يمكن إستخدامها في كل من أدوات المشرفين الفورية أو من خلال المواضيع نفسها., توضع ضمن الأدوات الإفتراضية للمشرفين.";

$l['post_tools'] = "أدوات الرد";
$l['post_tools_desc'] = "أدوات إضافية للمشرفين. تمكنك هذه الخاصية من إضافة أداة جديدة للمشرفين. يمكنهم إستخدامها لكل من المواضيع والردود. هذه الأدوات يمكن أن تستخدم مثل الأدوات الإفتراضية التي تظهر للمشرفين والإداريين في منتداك. ويمكنك هنا إدارة أدوات الردود.";

$l['add_post_tool'] = "أضف أداة رد";
$l['add_new_post_tool'] = "إضافة أداة رد جديدة";
$l['add_post_tool_desc'] = "يمكنك إضافة أداة اشرافية جديدة للردود. هذه الأداة يمكن إستخدامها من خلال المواضيع نفسها., توضع ضمن الأدوات الإفتراضية للمشرفين.";

$l['edit_post_tool'] = "ْتعديل أداة الردود";
$l['edit_post_tool_desc'] = "يمكنك من هنا تعديل إعدادات اداة المشاركات.";
$l['edit_thread_tool'] = "تعديل أداة المواضيع";
$l['edit_thread_tool_desc'] = "يمكنك من هنا تعديل إعدادات اداة المواضيع.";

$l['no_thread_tools'] = "ليس هناك أدوات اشرافية معدلة للمواضيع";
$l['no_post_tools'] = "ليس هناك أدوات اشرافية معدلة للردود";

$l['confirm_thread_tool_deletion'] = "متأكد من رغبتك في حذف أداة المواضيع هذه ؟";
$l['confirm_post_tool_deletion'] = "متأكد من رغبتك في حذف أداة الردود هذه ؟";

$l['success_post_tool_deleted'] = "تم حذف أداة الردود التي حددتها بنجاح.";
$l['success_thread_tool_deleted'] = "تم حذف أداة المواضيع التي حددتها بنجاح.";

$l['error_invalid_post_tool'] = "اداة المشاركة التي حددتها غير موجودة.";
$l['error_invalid_thread_tool'] = "أداة المواضيع التي حددتها غير موجودة.";

$l['general_options'] = "خيارات عامة";
$l['short_description'] = "وصف موجز";
$l['available_in_forums'] = "متوفرة في أقسام";
$l['available_to_groups'] = "متاح للمجموعات";
$l['show_confirmation'] = "اظهار صفحه التأكيد";
$l['save_thread_tool'] = "حفظ أداة المواضيع";

$l['title'] = "العنوان";

$l['thread_moderation'] = "إدارة المواضيع";
$l['approve_unapprove'] = "إعتماد/إلغاء إعتماد المواضيع ؟";

$l['no_change'] = "بدون تغيير";
$l['approve'] = "إعتماد";
$l['unapprove'] = "إلغاء إعتماد";
$l['stick'] = "تثبيت";
$l['unstick'] = "إلغاء التثبيت";
$l['open'] = "فتح";
$l['close'] = "إغلاق";
$l['stick'] = "تثبيت";
$l['unstick'] = "إلغاء التثبيت";
$l['toggle'] = "مسمار";
$l['days'] = "أيام";
$l['no_prefix'] = "بدون بادئة";
$l['restore'] = "استرجاع";
$l['softdelete'] = "حذف بسيط";

$l['forum_to_move_to'] = "أقسام للنقل إلى:";
$l['leave_redirect'] = "ترك إعادة التحويل ؟";
$l['delete_redirect_after'] = "حذف إعادة التحويل بعد";
$l['do_not_move_thread'] = "لا تنقل الموضوع";
$l['do_not_copy_thread'] = "لا تنسخ المشاركة";
$l['move_thread'] = "نقل الموضوع ؟";
$l['move_thread_desc'] = "إذا نقلت الموضوع / المواضيع, خاصية \"حذف إعادة التوجيه بعد .... يوم\" يجب أن يتم تعبئها فقط في حالة ترك إعادة تحويل.";
$l['forum_to_copy_to'] = "أقسام للنسخ إلى:";
$l['copy_thread'] = "نسخ الموضوع ؟";
$l['open_close_thread'] = "فتح/إغلاق الموضوع ؟";
$l['stick_unstick_thread'] = "تثبيت / إلغاء التثبيت";
$l['softdelete_restore_thread'] = "حذف بسيط / استرجاع ؟";
$l['delete_thread'] = "حذف الموضوع نهائيا ؟";
$l['merge_thread'] = "دمج المواضيع ؟";
$l['merge_thread_desc'] = "فقط في حالة إستخدام الأدوات الإشرافية الفوية.";
$l['delete_poll'] = "حذف الإستفتاء ؟";
$l['delete_redirects'] = "حذف إعادة التوجيه ؟";
$l['remove_subscriptions'] = "إلغاء الاشتراك بالموضوع ؟";
$l['recount_rebuild'] = "عد & اعادة بناء ؟";
$l['apply_thread_prefix'] = "تطبيق بادئة الموضوع؟";
$l['new_subject'] = "عنوان جديد ؟";
$l['new_subject_desc'] = "{subject} لطرح إسم الموضوع الأصلى قبل التغيير. {username} لطرح إسم مستخدم المشرف.";

$l['add_new_reply'] = "إضافة رد جديد";
$l['add_new_reply_desc'] = "أتركه فارغاً لعدم الرد";
$l['reply_subject'] = "عنوان الرد.";
$l['reply_subject_desc'] = "تستخدم فقط في حالة.<br />{subject} لطرح إسم الموضوع الأصلى قبل التغيير. {username} لطرح إسم مستخدم المشرف.";

$l['success_mod_tool_created'] = "تم إنشاء الأداة الإشرافية بنجاح";
$l['success_mod_tool_updated'] = "تم تحديث الأداة الإشرافية بنجاح";

$l['inline_post_moderation'] = "إدارة الردود الفورية";
$l['delete_posts'] = "حذف الردود نهائيا ؟";
$l['merge_posts'] = "دمج الردود ؟";
$l['merge_posts_desc'] = "فقط في حالة إستخدام الإشراف الفوري";
$l['approve_unapprove_posts'] = "إعتماد/إلغاء إعتماد الردود ؟";
$l['softdelete_restore_posts'] = "حذف بسيط / استرجاع الردود ؟";

$l['split_posts'] = "تقسيم الردود";
$l['split_posts2'] = "تقسم الردود ؟";
$l['do_not_split'] = "بدون تقسم الردود";
$l['split_to_same_forum'] = "التقسيم بداخل نفس القسم";
$l['close_split_thread'] = "إغلاق المواضيع المقسمة ؟";
$l['stick_split_thread'] = "تثبيت المواضيع المقسمة ؟";
$l['unapprove_split_thread'] = "إلغاء إعتماد المواضيع المقسمة ؟";
$l['split_thread_prefix'] = "تقسيم بادئه الموضوع ";
$l['split_thread_subject'] = "تقسم عنوان الموضوع";
$l['split_thread_subject_desc'] = "{subject} لطرح الموضوع الأصلى. مطلوب فقط في حالة تقسيم الردود.";
$l['add_new_split_reply'] = "أضف رد منقسم من الموضوع";
$l['add_new_split_reply_desc'] = "أتركه فارغاً لعدم الرد";
$l['split_reply_subject'] = "عنوان الرد";
$l['split_reply_subject_desc'] = "يستخدم فقط في حالة كتابة رد";
$l['save_post_tool'] = "حفظ أداة الرد";

$l['send_private_message'] = 'إرسال رساله خاصه';
$l['private_message_message'] = 'رساله';
$l['private_message_message_desc'] = 'لارسال رساله الي صاحب الموضوع . ان تركتها فارغه سيتم تعطيل الميزه.';
$l['private_message_subject'] = 'الموضوع';
$l['private_message_subject_desc'] = 'ادخل عنوان موضوع الرساله الخاصه.';

$l['error_missing_title'] = "من فضلك أدخل إسم لهذه الأداة";
$l['error_missing_description'] = "من فضلك أدخل وصف موجز لهذه الأداة";
$l['error_no_forums_selected'] = "من فضلك إختر الأقسام التي ستتوفر بها هذه الأداة";
$l['error_no_groups_selected'] = "من فضلك إختر الأقسام التي ستتوفر بها هذه الأداه";
$l['error_forum_is_category'] = "لا يمكن إختيار تصنيف على انه المنتدى المستهدف.";
