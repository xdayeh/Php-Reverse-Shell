<?php /** * MyBB 1.8.7 اللغة العربية لمنتديات * Copyright 2015 MyBB Group, All Rights Reserved *جميع حقوق التعريب محفوظه لمايكل سوفت http://miccsoft.com */



$l
['hello_desc'] = 'البرنامج المساعد عينة الذي يسمح لك بانشاء الرسائل على الصفحة وإلحاق كل وظيفة.';

$l
['setting_group_hello'] = 'ضبط المجموعة مرحبا';
$l
['setting_group_hello_desc'] = 'اعدادات تخص مجموعة مرحبا والترحيبية';

$l
['setting_hello_display1'] = 'عرض فهرس الرسائل';
$l
['setting_hello_display1_desc'] = 'تعيين إلى لا إذا كنت لا تريد عرض الرسائل الموجودة.';

$l
['setting_hello_display2'] = 'عرض رسالة Postbit';
$l
['setting_hello_display2_desc'] = 'تعيين إلى لا إذا كنت لا تريد عرض الرسائل الموجودة أسفل كل وظيفة.';

$l
['hello_uninstall'] = 'مرحبا بالعالم! إلغاء التثبيت';
$l
['hello_uninstall_message'] = 'هل ترغب في تفريغ كافة الرسائل من قاعدة البيانات؟';