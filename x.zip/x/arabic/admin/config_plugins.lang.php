<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['plugins'] = "الهاكات Plugins";
$l['plugins_desc'] = "لتفعيل أو تعطيل الهاكات, وإدارة الهاكات التي قمت برفعها إلى مجلد <strong>inc/plugins</strong>. لإخفاء بعض الهاكات, بدون خسارة أي من إعدادتها المحفوظة فقط, إضغط على رابط التعطيل.";
$l['plugin_updates'] = "تحديثات الهاكات";
$l['plugin_updates_desc'] = "هذا الجزء لفحص أي تحديث تم طرحه لجميع الهاكات التي لديك.";
$l['browse_plugins'] = "تصفح الهاكات";
$l['browse_plugins_desc'] = "من خلال هذه الصفحة يمكنك تصفح الهاكات من موقع MyBB الرسمى والمتوافقة مع إصدار منتداك";
$l['browse_all_plugins'] = "تصفح كل الهاكات";

$l['plugin'] = "الهاك";
$l['active_plugin'] = "الهاكات المفعله";
$l['inactive_plugin'] = "الهاكات المعطله";
$l['your_version'] = "الأصدار الذي لديك";
$l['latest_version'] = "آخر اصدار متوفر";
$l['download'] = "تحميل";
$l['deactivate'] = "تعطيل";
$l['activate'] = "تفعيل";
$l['install_and_activate'] = "تثبيت و تفعيل";
$l['uninstall'] = "إلغاء التثبيت";
$l['created_by'] = "برمجة";
$l['no_plugins'] = "لا يوجد هاكات في منتداك حالياً.";
$l['no_active_plugins'] = "لا يوجد هاكات مفعله الان.";
$l['no_inactive_plugins'] = "لا يوجد هاكات معطله الان";

$l['plugin_incompatible'] = "الهاك غير متوافق مع MyBB {1}";

$l['recommended_plugins_for_mybb'] = "الهاكات التي ينصح بها لـ MyBB {1}";
$l['browse_results_for_mybb'] = "نتائج البحث لـ MyBB {1}";
$l['search_for_plugins'] = "البحث عن الهاكات";
$l['search'] = "بحث";

$l['error_vcheck_no_supported_plugins'] = "لا يوجد أي هاك من الهاكات المثبتة في منتداك يدعم نظام فحص الإصدار";
$l['error_vcheck_communications_problem'] = "حدث خطأ ما أثناء محاولة الإتصال مع سيرفر فحص الإصدار. من فضلك أعد المحاولة بعد دقائق.";
$l['error_vcheck_vulnerable'] = "[هاكات غير مؤمنه]:";
$l['error_vcheck_vulnerable_notes'] = "هذا الخيار مقدم من فريق عمل النسخه. نوصي بازاله كامله لهذا. وبرجاء مراجعه الملاحظات ادناه : ";
$l['error_no_input'] = "خطأ رقم 1: لا يوجد استعلام محدد.";
$l['error_no_pids'] = "خطأ رقم 2: لا يوجد معرّف محددة للهاك.";
$l['error_communication_problem'] = "حدث خطأ ما أثناء محاولة الإتصال مع سيرفر فحص الإصدار.";
$l['error_invalid_plugin'] = "الهاك الذي حددته غير موجود.";
$l['error_no_results_found'] = "لم يتم العثور على أي نتائج تتوافق مع الكلمات التي تبحث عنها.";

$l['success_plugins_up_to_date'] = "تهانينا. جميع الهاكات المثبتة لديك محدثة لأخر اصدار.";
$l['success_plugin_activated'] = "تم تفعيل الهاك بنجاح.";
$l['success_plugin_deactivated'] = "تم تعطيل الهاك بنجاح.";
$l['success_plugin_installed'] = "تم تثبيت وتفعيل الهاك بنجاح.";
$l['success_plugin_uninstalled'] = "تم إلغاء تثبيت الهاك بنجاح";
