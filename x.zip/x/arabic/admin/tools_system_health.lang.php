<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['system_health'] = "كفاءة النظام";
$l['system_health_desc'] = "لعرض معلومات عن نظامك وكفاءته.";
$l['utf8_conversion'] = "التحويل لترميز UTF-8";
$l['utf8_conversion_desc'] = "نقوم حالياً بعملية تحويل ترميز جداول قاعدة البيانات. ليكن في معلومك هذا الأمر ربما يتطلب عدة ساعات, على حسب حجم قاعدة بيانات والبيانات المخزنة بها. عندما ينتهي الإجراء سوف يتم التحويل لصفحة تحويل الترميز لـ UTF-8 الرئيسية.";
$l['utf8_conversion_desc2'] = "هذه الإدارة لفحص جداول قاعدة البيانات للتأكد من أنهم يعملوا تحت الترميز UTF-8 أو تحويلهم لهذا الترميز إذا لم يكونوا كذلك.";

$l['convert_all'] = "تحويل الكل.";
$l['converting_to_utf8'] = "يجري الآن تحويل جدول \"{1}\" إلى الترميز UFT-8 بدلاً من الترميز {2} .";
$l['convert_to_utf8'] = "أنت على وشك تحويل جدول \"{1}\" إلى الترميز UTF-8 بدلاً من الترميز {2} .";
$l['convert_all_to_utf'] = "أنت على وشك تحويل جميع جداول قاعدة البيانات إلى الترميز UTF-8 بدلاً من ترميز {1}.";
$l['convert_all_to_utf8mb4'] = "You are about to convert ALL tables to 4-Byte UTF-8 Unicode language encoding from {1} encoding.";
$l['converting_to_utf8mb4'] = "MyBB is currently converting \"{1}\" table to 4-Byte UTF-8 Unicode language encoding from {2} encoding.";
$l['please_wait'] = "إنتظر من فضلك...";
$l['converting_table'] = "يجري تحويل جدول:";
$l['convert_table'] = "تحويل الجدول";
$l['convert_tables'] = "تحويل جميع الجداول";
$l['convert_database_table'] = "تحويل جدول قاعدة البيانات";
$l['convert_database_tables'] = "تحويل جميع جداول قاعدة البيانات";
$l['table'] = "الجدول";
$l['status_utf8'] = "UTF-8 Status";
$l['status_utf8mb4'] = "4-Byte UTF-8 Support<br />(requires MySQL 5.5.3 or above)";
$l['not_available'] = "غير متاح";
$l['all_tables'] = "All Tables";
$l['convert_now'] = "التحويل الآن";
$l['totals'] = "الإجمالي";
$l['attachments'] = "المرفقات";
$l['total_database_size'] = "إجمالي حجم قاعدة البيانات";
$l['attachment_space_used'] = "مساحة المرفقات المستخدمة";
$l['total_cache_size'] = "مساحة الملفات التخزينية Cache المستخدمة";
$l['estimated_attachment_bandwidth_usage'] = "الترافيك المستهلك بواسطة المرفقات (تقريباً)";
$l['max_upload_post_size'] = "الحد الأقصى للرفع / حجم الإرسال";
$l['average_attachment_size'] = "معدل حجم المرفقات";
$l['stats'] = "إحصائية";
$l['task'] = "المهمة";
$l['run_time'] = "وقت التشغيل";
$l['next_3_tasks'] = "المهام الـ 3 التالية";
$l['no_tasks'] = "لا يوجد مهام تعمل الان";
$l['backup_time'] = "وقت النسخ الإحتياطي";
$l['no_backups'] = "لا يوجد نُسَخ إحتياطية حالياً.";
$l['existing_db_backups'] = "النُسَخ الإحتياطية التي تم إنشاؤها";
$l['writable'] = "قابل للكتابة";
$l['not_writable'] = "غير قابل للكتابة";
$l['please_chmod_777'] = "من فضلك اعطى التصاريح CHMOD 777";
$l['chmod_info'] = "من فضلك قم بتغيير التصاريح CHMOD للملف/الملفات الموجودة أدناه إلى التصاريح 777";
$l['file'] = "الملف";
$l['location'] = "مكانه";
$l['settings_file'] = "ملف الإعدادات";
$l['config_file'] = "ملف الخصائص";
$l['file_upload_dir'] = "مجلد رفع الملفات";
$l['avatar_upload_dir'] = "مجلد رفع الصور الرمزية";
$l['language_files'] = "ملفات اللغة";
$l['backup_dir'] = "مجلد النُسَخ الإحتياطية";
$l['cache_dir'] = "مجلد الملفات التخزينية";
$l['themes_dir'] = "مجلد الإستايلات";
$l['chmod_files_and_dirs'] = "قم بإعداد الـ CHMOD للملفات والمجلدات";

$l['notice_process_long_time'] = "ربما يتطلب الإجراء عدة ساعات متوقف على حجم جداول منتداك.";
$l['notice_mb4_warning'] = "4-Byte UTF-8 Support requires MySQL 5.5.3 or above. You will not be able to import your database on a MySQL server with another version.";

$l['check_templates'] = "فحص القوالب";
$l['check_templates_desc'] = "Checks all installed templates for known security issues.";
$l['check_templates_title'] = "فحص امان القالب";
$l['check_templates_info'] = "This process will check your templates against security issues that could affect your forum and the server it runs on. This might take a while if you've installed many themes.
<br /><br />To start the process, press the 'Proceed' button below.";
$l['check_templates_info_desc'] = "The templates below matched known security issues. Please review them.";
$l['full_edit'] = "Full Edit";

$l['error_chmod'] = "جميع الملفات والمجلدات ليس لديها تصاريح الـ CHMOD الصحيحة";
$l['error_invalid_table'] = "الجدول الذي حددته غير موجود.";
$l['error_db_encoding_not_set'] = "التنصيب الحالي لمنتدى MyBB لا يستخدم هذه الأداة بعد . رجاءاً شاهد <a href=\"http://wiki.mybboard.net/index.php/UTF8_Setup\">the wiki</a> لمزيد من المعلومات عن كيفية غعدادها .";
$l['error_not_supported'] = "محرك قاعدة البيانات لديك (DB Engine) غير مدعوم بواسطة أداة تحويل الترميز إلى UTF-8";
$l['error_invalid_input'] = "There was a problem checking the templates. Please try again or contact the MyBB Group for support.";
$l['error_master_templates_altered'] = "The Master Templates have been altered. Please contact the MyBB Group for support on how to alter these.";
$l['error_utf8mb4_version'] = "Your MySQL version doesn't support 4-Byte UTF-8 encoding.";


$l['warning_multiple_encodings'] = "نوصي بعدم استخدام ترميزات مختلفة في قاعدة البيانات مما قد يؤدي الي مشاكل في قاعدة البيانات";
$l['warning_utf8mb4_config'] = "For full 4-Byte UTF-8 support you need to change <i>\$config['database']['encoding'] = 'utf8';</i> to <i>\$config['database']['encoding'] = 'utf8mb4';</i> in your inc/config.php.";

$l['success_templates_checked'] = "فحص القوالب تم بنجاح - لا يوجد مشاكل أمنية ";
$l['success_all_tables_already_converted'] = "جميع الجداول تعمل تحت الترميز UTF-8 بالفعل.";
$l['success_table_converted'] = "الجدول المحدد \"{1}\" تم تحويل ترميزه إلى UTF-8 بنجاح.";
$l['success_chmod'] = "جميع الملفات والمجلدات لديها تصاريح الـ CHMOD الصحيحة";
