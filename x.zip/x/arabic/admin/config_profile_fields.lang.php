<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['custom_profile_fields'] = "حقول الملف الشخصي الإضافية";
$l['custom_profile_fields_desc'] = "لتعديل, حذف , إدارة حقول الملف الشخصي الإضافية";
$l['add_profile_field'] = "إضافة حقل";
$l['add_new_profile_field'] = "إضافة حقل جديد";
$l['add_new_profile_field_desc'] = "لإضافة حقل للملف الشخصي جديد";
$l['edit_profile_field'] = "تعديل حقل";
$l['edit_profile_field_desc'] = "لتعديل أحد الحقول التي قمت بإنشاءها سابقاً";

$l['title'] = "العنوان";
$l['short_description'] = "وصف موجز";
$l['maximum_length'] = "الحد الأقصى";
$l['maximum_length_desc'] = "الحد الأقصى لعدد الحروف التي يمكن إدخالها. تطبق هذه الخاصية فقط على حقول, الصندوق النصي, والمنطقة النصية.";
$l['field_length'] = "طول الحقل";
$l['field_length_desc'] = "طول الحقل, يطبق فقط على صناديق الإختيار الفردى أو الإختيار المتعدد.";
$l['display_order'] = "ترتيب العرض";
$l['display_order_desc'] = "هذا الترتيب, هو ترتيب ظهور الحقل ضمن بقية الحقول الإضافية. يجب أن لا يكون هذا الرقم مثل رقم أحد الحقول الأخرى.";
$l['text'] = "صندوق نصي";
$l['textarea'] = "منطقة نصية";
$l['select'] = "صندوق إختيار فردى";
$l['multiselect'] = "صندوق إختيار متعدد";
$l['radio'] = "ازرار";
$l['checkbox'] = "صناديق تحديد Check Boxes";
$l['field_type'] = "نوع الحقل";
$l['field_type_desc'] = "هذا هو نوع الحقل الذي سيعرض";
$l['field_regex'] = "حقل صحيح";
$l['field_regex_desc'] = "هذا يمكنك من اضافة حقل مطلوب صحيح لا يمكن تجاهله او كتابه شي غير صحيح به ويكون امن.<br />
<strong>كمثال:</strong> ([a-z0-9_\- ,.+]+)";
$l['selectable_options'] = "إختيارات قابلة للإختيار منها ؟";
$l['selectable_options_desc'] = "من فضلك أدخل كل إختيار في سطر منفصل. هذا النظام مطبق فقط على أنواع الحقول, صناديق التحديد, والأزرار.";
$l['required'] = "إجبارى ؟";
$l['required_desc'] = "هل هذا الحقل إجباري عند التسجيل أو تعديل الملف الشخصي ؟ لاحظ أن هذا الحقل لن يكون إجباري إذا تم إخفائه.";
$l['show_on_registration'] = "عرض بالتسجيل";
$l['show_on_registration_desc'] = "تريد ان يظهر في صفحة التسجيل ؟ ";
$l['display_on_profile'] = "عرض بالملف الشخصي";
$l['display_on_profile_desc'] = "يظهر علي ملف الاعضاء مع العلم لا ينطبق علي المشرفين والاداريين.";
$l['display_on_postbit'] = "عرض بالبوست بت";
$l['display_on_postbit_desc'] = "هل تريد اظهاره بالمشاركات بالبوست بت";
$l['viewableby'] = 'مشاهده بواسطه';
$l['viewableby_desc'] = 'اختار مجموعه الاعضاء التي تستطيع مشاهده هذا الحقل بالملف الشخصي.';
$l['editableby'] = 'تعديل بواسطه';
$l['editableby_desc'] = 'اختار مجموعه الاعضاء التي تستطيع مشاهده حقل التعديل للملف الشخصي.';
$l['min_posts_enabled'] = "الحد الادني للمشاركات ؟";
$l['min_posts_enabled_desc'] = "ادخل عدد المشاركات المطلوب في حالة تفعيل الخاصية ليتم الاخذ بالاعتبار في عدد مشاركات العضو ليكون قادر علي تنفيذها";
$l['parser_options'] = "خيارات الاكواد";
$l['parse_allowhtml'] = "السماح باستخدام الهتمل ( HTML) في حقول الملف الشخصي.";
$l['parse_allowmycode'] = "السماح باستخدام اكواد الحرر في حقول الملف الشخصي";
$l['parse_allowsmilies'] = "السماح بالابتسامات في حقول الملف الشخصي";
$l['parse_allowimgcode'] = "السماح بكود الصور في حقول الملف الشخصي.";
$l['parse_allowvideocode'] = "السماح بكود الفيديو في حقول الملف الشخصي";
$l['save_profile_field'] = "حفظ الحقل";
$l['name'] = "الإسم";
$l['registration'] = "تسجيل؟";
$l['editable'] = "قابل للتعديل ؟";
$l['profile'] = "الملف الشخصي";
$l['postbit'] = "البوست بت";
$l['edit_field'] = "تعديل الحقل";
$l['delete_field'] = "حذف الحقل";
$l['no_profile_fields'] = "لا يوجد حقول إضافية للملفات الشخصية في منتداك حالياً.";

$l['error_missing_name'] = "لم تقم بإدخال عنوان هذا الحقل.";
$l['error_missing_description'] = "لم تقم بإدخال وصف موجز لهذا الحقل.";
$l['error_invalid_fid'] = "الحقل الذي إخترته غير موجود.";

$l['success_profile_field_added'] = "تم إضافة الحقل الإضافي بنجاح.";
$l['success_profile_field_saved'] = "تم حفظ الحقل بنجاح.";
$l['success_profile_field_deleted'] = "تم حذف الحقل بنجاح.";

$l['confirm_profile_field_deletion'] = "متأكد من رغبتك في حذف هذا الحقل ؟";
