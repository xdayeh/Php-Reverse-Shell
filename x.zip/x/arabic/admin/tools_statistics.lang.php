<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */
 
$l['statistics'] = "الإحصائيات";
$l['overall_statistics'] = "إجمالي الإحصائيات";
$l['overall_statistics_desc'] = "يمكنك مشاهدة إجمالي إحصائيات منتداك من هنا.";

$l['date_range'] = "نطاق التاريخ";

$l['date'] = "التاريخ";
$l['users'] = "المستخدمون";
$l['threads'] = "المواضيع";
$l['posts'] = "المشاركات";

$l['from'] = "من";
$l['to'] = "إلى";

$l['increase'] = "زيادة";
$l['no_change'] = "بدون تغيير";
$l['decrease'] = "تقليل";

$l['error_no_results_found_for_criteria'] = "لم نتمكن من إيجاد أي نتائج في نطاق التاريخ الذي حددته, من فضلك حدد نطاق تاريخ آخر.";
$l['error_no_statistics_available_yet'] = "عفوا, لا يوجد أي إحصائيات متوفرة في منتداك حتى الأن.";
