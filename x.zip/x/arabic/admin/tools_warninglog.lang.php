<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */


$l['warning_logs'] = "سجلات التحذيرات";
$l['warning_logs_desc'] = "لمشاهدة سجل التحذيرات التي تم إعطائها للأعضاء .";
$l['warned_user'] = "الأعضاء الذين تم تحذيرهم";
$l['warning'] = "التحذير";
$l['date_issued'] = "تاريخ التحذير";
$l['expires'] = "ينتهي في";
$l['expiry_date'] = "تاريخ الإنتهاء";
$l['issued_date'] = "تاريخ التحذير";
$l['issued_by'] = "تم التحذير بواسطة";
$l['details'] = "التفاصيل";
$l['filter_warning_logs'] = "ترشيح سجلات التحذير";
$l['filter_warned_user'] = "العضو الذي تم تحذيره:";
$l['filter_issued_by'] = "التحذير بواسطة:";
$l['filter_reason'] = "سبب التحذير يحتوي على:";
$l['sort_by'] = "ترتيب بواسطة:";
$l['results_per_page'] = "النتائج لكل صفحة:";
$l['view'] = "مشاهدة";
$l['no_warning_logs'] = "لا يوجد سجلات تحذير لمشاهدتها.";
$l['revoked'] = "إلغاء";
$l['post'] = "مشاركة";

$l['asc'] = "تصاعدي";
$l['desc'] = "تنازلي";

$l['in'] = "في";
$l['order'] = "ترتيب";

$l['warning_details'] = "تفاصيل التحذير";
$l['warning_note'] = "ملاحظات الإدارة";
$l['already_expired'] = "منتهي";
$l['warning_revoked'] = "إلغاء";
$l['warning_active'] = "مفعـّل";
$l['error_invalid_warning'] = "التحذير الذي حددته خاطيء.";

$l['revoke_warning'] = "إلغاء هذا التحذير";
$l['revoke_warning_desc'] = "لإلغاء التحذير من فضلك أدخل سبب هذا الإجراء. هذا لن يلغي أي حظر أو إيقاف حدث بسبب هذا التحذير.";
$l['reason'] = "السبب:";
$l['warning_is_revoked'] = "تم إلغاء التحذير";
$l['revoked_by'] = "تم الإلغاء بواسطة:";
$l['date_revoked'] = "تاريخ الإلغاء:";
$l['error_already_revoked'] = "هذا التحذير ملغي مسبقاً.";
$l['error_no_revoke_reason'] = "لم تقم بكتابة سبب إلغائك لهذا التحذير.";
$l['redirect_warning_revoked'] = "هذا التحذير تم إلغاؤه بنجاح, وتم تقليص عدد نقاط التحذير للمستخدم.";
