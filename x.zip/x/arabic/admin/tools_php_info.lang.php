<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['php_info'] = "معلومات الـ PHP";
$l['browser_no_iframe_support'] = "متصفحك لا يدعم الإطارات iframes";

