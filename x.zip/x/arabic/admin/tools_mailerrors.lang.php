<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['system_email_log'] = "سجل النظام البريدي";
$l['system_email_log_desc'] = "جميع الرسائل البريدية التي تم إنشاؤها بواسطة المنتدى وحدث خلل أثناء إرسالها يتم حفظها وعرضها أدناه. هذه السجلات مفيدة لتعريف أخطاء إعدادات الـ SMTP أو لتعريف دعم النظام البريدي بخادمك";
$l['prune_system_email_log'] = "حذف سجل النظام البريدي";
$l['filter_system_email_log'] = "ترشيح سجل النظام البريدي";

$l['close_window'] = "أغلق الصفحة";
$l['user_email_log_viewer'] = "مُسَتخدِم عرض سجل البريد";
$l['smtp_code'] = "كود SMTP:";
$l['smtp_server_response'] = "إستجابة سيرفر الـ SMTP:";
$l['to'] = "إلى";
$l['from'] = "من";
$l['subject'] = "العنوان";
$l['date'] = "التاريخ";
$l['email'] = "البريد";
$l['date_sent'] = "تاريخ الإرسال";
$l['error_message'] = "رسالة الخطأ";
$l['fine'] = "بحث";
$l['no_logs'] = "لا يوجد بيانات في السجل متوافقة مع المعايير التي حددتها";
$l['subject_contains'] = "العنوان يحتوي على";
$l['error_message_contains'] = "رسالة الخطأ تحتوي على";
$l['to_address_contains'] = "إلى عنوان يحتوي على";
$l['from_address_contains'] = "من عنوان يحتوي على";
$l['find_emails_to_addr'] = "أوجد كل الرسائل البريدية التي أرسلت إلى عنوان";

