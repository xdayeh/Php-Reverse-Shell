<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['post_icons'] = "رموز المشاركات";
$l['add_post_icon'] = "إضافة رمز جديد";
$l['add_post_icon_desc'] = "لإضافة رمز جديد يمكن إستخدامه في عناوين المواضيع";
$l['add_multiple_post_icons'] = "إضافة رموز عديدة";
$l['add_multiple_post_icons_desc'] = "لإضافة عدة رموز في وقت واحد.";
$l['edit_post_icon'] = "تعديل رمز المواضيع.";
$l['edit_post_icon_desc'] = "لتعديل الرموز التي تم إضافتها مسبقاً.";
$l['manage_post_icons'] = "إدارة رموز المشاركة";
$l['manage_post_icons_desc'] = "لتعديل وحذف وإدارة رموز المشاركات.";

$l['name_desc'] = "إسم رمز المشاركة";
$l['image_path'] = "مسار الصورة";
$l['image_path_desc'] = "مسار صورة الرمز";
$l['save_post_icon'] = "حفظ الرمز";
$l['reset'] = "تفريغ";

$l['path_to_images'] = "مسار الصور";
$l['path_to_images_desc'] = "مسار مجلد صور الرموز التي تريد إضافتها.";
$l['show_post_icons'] = "عرض رموز المشاركات";
$l['image'] = "الصورة";
$l['add'] = "إضافة ؟";
$l['save_post_icons'] = "حفظ الرمز";

$l['no_post_icons'] = "لا يوجد رموز للمشاركات في منتداك حالياً.";

$l['error_missing_name'] = "لم تقم بإدخال إسم للرمز";
$l['error_missing_path'] = "لم تدخل مسار صورة الرمز";
$l['error_missing_path_multiple'] = "لم تحدد المسار";
$l['error_invalid_path'] = "لقد أدخلت مسار خاطيء";
$l['error_no_images'] = "لا يوجد رموز بداخل المجلد الذي حددته, أو جميع الرموز التي بداخل المجلد الذي حددته مضافة بالفعل.";
$l['error_none_included'] = "لم تحدد أي رموز لضمها.";
$l['error_invalid_post_icon'] = "الرمز الذي حددته غير موجود.";

$l['success_post_icon_added'] = "تم إضافة الرمز بنجاح";
$l['success_post_icons_added'] = "تم إضافة الرموز التي حددتها بنجاح.";
$l['success_post_icon_updated'] = "تم تعديل الرمز بنجاح.";
$l['success_post_icon_deleted'] = "تم حذف الرمز بنجاح.";

$l['confirm_post_icon_deletion'] = "متأكد من رغبتك في حذف الرمز ؟";
