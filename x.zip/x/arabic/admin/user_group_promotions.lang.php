<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['user_group_promotions'] = "ترقيات مجموعة المستخدم";
$l['user_group_promotions_desc'] = "لإدارة ترقية مجموعة المستخدمين.";
$l['edit_promotion'] = "تعديل الترقية";
$l['edit_promotion_desc'] = "لتعديل الترقيات التي تعمل بشكل تلقائي في منتداك.";
$l['add_new_promotion'] = "أضف ترقية جديدة";
$l['add_new_promotion_desc'] = "لإنشاء ترقية جديدة تعمل بشكل تلقائي في منتداك.";

$l['title'] = "العنوان";
$l['short_desc'] = "وصف موجز";
$l['post_count'] = "عدد المشاركات";
$l['thread_count'] = "عدد المواضيع";
$l['reputation'] = "السمعة";
$l['referrals'] = "الإحالات";
$l['time_registered'] = "فترة التسجيل";
$l['time_online'] = "فترة البقاء";
$l['promo_requirements'] = "متطلبات الترقية";
$l['promo_requirements_desc'] = "إختر المعايير التي يجب توافرها لتتناسب مع هذه الترقية. إضغط مع الإستمرار على زر CTRL لإختيار عدة معايير.";
$l['greater_than_or_equal_to'] = "أكثر من أو يساوي";
$l['greater_than'] = "أكثر من";
$l['equal_to'] = "يساوي";
$l['less_than_or_equal_to'] = "أقل من أو يساوي";
$l['less_than'] = "أقل من";
$l['reputation_count'] = "عدد نقاط السمعة";
$l['reputation_count_desc'] = "أدخل معدل السمعة المطلوب. يجب أن تكون السمعة أحد المعايير المطلوبة ليتم تضمين هذا المعدل. إختر نوع لمقارنة السمعة.";
$l['referral_count'] = "عدد الإحالات";
$l['referral_count_desc'] = "أدخل عدد الإحالات المطلوب. يجب إختيار عدد الإحالات كقيمة مطلوبة. إختر نوع مقارنة الإحالات.";
$l['warning_points'] = "عدد التحذيرات";
$l['warning_points_desc'] = "ادخل عدد التحذيرات المطلوبه.";
$l['post_count_desc'] = "أدخل عدد المشاركات المطلوب. عدد المشاركات يجب أن يكون أحد المعايير المطلوبة, ليتم تضمين قيمة هذا الإختيار. إختر نوع لمقارنة عدد المشاركات.";
$l['thread_count_desc'] = "ادخل عدد المواضيع المطلوبه . عدد المواضيع يجب ان يكون أحد المعايير المطلوبه . ليتم تضمين هذا الاختيار . إختر نوع لمقارنة عدد المواضيع";
$l['hours'] = "ساعات";
$l['days'] = "أيام";
$l['weeks'] = "أسابيع";
$l['months'] = "شهور";
$l['years'] = "سنوات";
$l['time_registered_desc'] = "أدخل عدد, الساعات, الأيام, الأسابيع, الشهور, والسنوات, التي يجب أن يكون أمضاها هذا العضو وهو مسجل في المنتدى. فترة التسجيل يجب أن يكون تم إختياره كأحد المعايير المطلوبة. ليتم الأخذ بقيمة هذا الإختيار. إختر أيهما فترة التسجيل يجب أن يتم عدها بالترتيب, ساعات, أيام, أسابيع, شهور و سنوات.";
$l['time_online_desc'] = "Enter the number of hours, days, weeks, months, or years that this user must have been online for. Time online must be selected as a required value for this to be included. Select whether the time spend online should be counted in hours, days, weeks, months, or years.";
$l['all_user_groups'] = "كل مجموعات الأعضاء";
$l['orig_user_group'] = "مجموعة العضو الأصلية";
$l['orig_user_group_desc'] = "إختر أي مجموعة للعضو, أو مجموعات الأعضاء التي يجب أن يكون العضو أحد أعضائها ليتم تطبيق نظام الترقية هذا عليه. إضغط مع الإستمرار على CTRL لإختيار أكثر من مجموعة. إختر 'كل مجموعات الأعضاء' إذا كنت ترغب أن يكون نظام الترقية هذا متوفر لكل المجموعات.";
$l['new_user_group'] = "مجموعة أعضاء جديدة";
$l['new_user_group_desc'] = "إختر المجموعة التي سيتم نقل العضو إليها بعد أن تتناسب بياناته مع معايير الترقية التي حددتها.";
$l['primary_user_group'] = "مجموعة الأعضاء الرئيسية";
$l['secondary_user_group'] = "مجموعة الأعضاء الثانوية";
$l['user_group_change_type'] = "نوع تغيير مجموعة الأعضاء";
$l['user_group_change_type_desc'] = "إختر 'مجموعة الأعضاء الرئيسية' إذا كان يجب أن يتم تغيير مجموعة العضو الرئيسية للمجموعة الجديدة عندما يتم ترقيتهم. إختر 'مجموعة أعضاء إضافية'إذا كان يجب أن يتم إضافة مجموعة الأعضاء الجديدة داخل ملف العضو الشخصي.";
$l['enabled'] = "مفعلة ؟";
$l['enable_logging'] = "تفعيل السجل ؟";
$l['promotion_logs'] = "سجل الترقية";
$l['view_promotion_logs'] = "مشاهدة سجل الترقية";
$l['view_promotion_logs_desc'] = "لمشاهدة سجل الترقيات التي تم تشغيلها سابقاً.";
$l['promoted_user'] = "الأعضاء الذين تم ترقيتهم";
$l['time_promoted'] = "وقت الترقية";
$l['no_promotion_logs'] = "لا يوجد سجل ترقيات حالياً.";
$l['promotion_manager'] = "إدارة الترقيات";
$l['promotion'] = "الترقية";
$l['disable_promotion'] = "تعطيل الترقية";
$l['enable_promotion'] = "تفعيل الترقية";
$l['delete_promotion'] = "حذف الترقية";
$l['no_promotions_set'] = "لا يوجد إعداد ترقيات حالياً.";
$l['update_promotion'] = "حفظ الترقية";
$l['multiple_usergroups'] = "مجموعات أعضاء متعددة";
$l['secondary'] = "الثانوي";
$l['primary'] = "الرئيسي";

$l['error_no_promo_id'] = "لم تقم بإدخال معرّف الترقية";
$l['error_invalid_promo_id'] = "لم تقم بإدخال معرّف ترقية صحيحة.";

$l['error_no_title'] = "لم تقم بإدخال عنوان لهذه الترقية.";
$l['error_no_desc'] = "لم تقم بإدخال وصف هذه الترقية.";
$l['error_no_requirements'] = "لم تقم بتحديد أحد المعايير لهذه الترقية.";
$l['error_no_orig_usergroup'] = "لم تقم بتحديد مجموعة عضو أصلية واحدة على الأقل لهذا الترقية.";
$l['error_no_new_usergroup'] = "لم تقم بتحديد مجموعة عضو جديد واحدة على الأقل لهذه الترقية.";
$l['error_no_usergroup_change_type'] = "لم تقم بتحديد نوع التغيير الذي يتم تطبيقه على هذه الترقية.";

$l['success_promo_disabled'] = "تم تعطيل الترقية بنجاح.";
$l['success_promo_deleted'] = "تم حذف الترقية بنجاح.";
$l['success_promo_enabled'] = "تم تفعيل الترقية بنجاح.";
$l['success_promo_updated'] = "تم تحديث الترقية بنجاح.";
$l['success_promo_added'] = "تم إضافة الترقية بنجاح.";

$l['confirm_promo_disable'] = "هل أنت متأكد من رغبيتم لتعطيل هذه الترقية ؟";
$l['confirm_promo_deletion'] = "متأكد من رغبتك في حذف هذه الترقية ؟";

