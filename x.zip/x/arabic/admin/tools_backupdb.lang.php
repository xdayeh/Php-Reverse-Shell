<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */


$l['database_backups'] = "نُسَخ قاعدة البيانات";
$l['database_backups_desc'] = "قائمة بِنُسَخ قاعدة البيانات المحفوظة بمجلد نُسَخ قاعدة البيانات التي تم أخذها مَسبقاً";
$l['new_database_backup'] = "نسخ إحتياطي جديد لقاعدة البيانات";
$l['new_backup'] = "نسخ جديد";
$l['new_backup_desc'] = "لإنشاء نسخة إحتياطية جديدة لقاعدة البيانات";
$l['backups'] = "النُسَخ الإحتياطية";
$l['existing_database_backups'] = "النُسَخ الإحتياطية الموجودة";

$l['backup_saved_to'] = "تم حفظ النسخة الإحتياطية في:";
$l['download'] = "تحميل";
$l['table_selection'] = "إختيار الجداول";
$l['backup_options'] = "خيارات النسخ الإحتياطي";
$l['table_select_desc'] = "يمكنك إختيار الجداول التي يتم تطبيق النسخ عليها. قم بالضغط مع الإستمرار على زر CTRL لإختيار أكثر من جدول.";
$l['select_all'] = "إختر الكل";
$l['deselect_all'] = "إلغاء تحديد الكل";
$l['select_forum_tables'] = "إختر جداول المنتدى";
$l['file_type'] = "نوع الملف";
$l['file_type_desc'] = "حدد نوع ملف النسخة الإحتياطية الذي يتم حفظه.";
$l['gzip_compressed'] = "مضغوط بصيغة GZIP";
$l['plain_text'] = "ملف سيكوال عادي";
$l['save_method'] = "طريقة الحفظ";
$l['save_method_desc'] = "حدد طريقة الحفظ التي تريد حفظ ملف النسخة الإحتياطية به";
$l['backup_directory'] = "مجلد النسخ الإحتياطية";
$l['backup_contents'] = "محتوى النسخ الإحتياطي";
$l['backup_contents_desc'] = "إختر البيانات التي تود حفظها في ملف النسخ الإحتياطي";
$l['structure_and_data'] = "هيكل البناء والبيانات";
$l['structure_only'] = "هيكل البناء فقط (شكل وخصائص الجداول)";
$l['data_only'] = "البيانات فقط";
$l['analyze_and_optimize'] = "تحليل وتحسين الجداول التي حددتها";
$l['analyze_and_optimize_desc'] = "هل تريد أن يتم تحليل وتحسين الجداول أثناء عملية النسخ الإحتياطي ؟";
$l['perform_backup'] = "إبدأ النسخ";
$l['backup_filename'] = "إسم ملف النسخة الإحتياطية";
$l['file_size'] = "حجم الملف";
$l['creation_date'] = "تاريخ الإنشاء";
$l['no_backups'] = "لا يوجد حالياً نُسَخ إحتياطية محفوظة.";

$l['error_file_not_specified'] = "لم تقم بتحديد أي نسخة إحتياطية لتحميلها.";
$l['error_invalid_backup'] = "ملف النسخة الإحتياطية الذي حددته إما خاطيء أو غير موجود.";
$l['error_backup_doesnt_exist'] = "النسخة التي حددتها غير موجودة.";
$l['error_backup_not_deleted'] = "لم يتم حذف ملف النسخة الإحتياطية.";
$l['error_tables_not_selected'] = "لم تقم بتحديد أي جداول لتطبيق النسخ الإحتياطي عليها";
$l['error_no_zlib'] = "دالة الـ zlib library للـ PHP غير مفعلة. بالتالي لا يمكنك ضغط النُسَخ الإحتياطية.";

$l['alert_not_writable'] = "مجلد النسخ الإحتياطي (الموجود داخل مجلد الإدارة) غير قابل للكتابة. بالتالي لا يمكنك حفظ النسخ على خادمك.";

$l['confirm_backup_deletion'] = "متأكد من رغبتك في حذف النسخة الإحتياطية ؟";

$l['success_backup_deleted'] = "تم حذف النسخة الإحتياطية بنجاح.";
$l['success_backup_created'] = "تم إنشاء النسخة الإحتياطية بنجاح.";

