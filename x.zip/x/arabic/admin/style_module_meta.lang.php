<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['templates_and_style'] = "القوالب و الإستايلات";

$l['themes'] = "الإستايلات";
$l['templates'] = "القوالب";

$l['can_manage_themes'] = "يمكنه إدارة الإستايلات ؟";
$l['can_manage_templates'] = "يمكنه إدارة القوالب ؟";

