<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['help_documents'] = "وثائق المساعدة";
$l['add_new_section'] = "إضافة قسم جديد";
$l['add_new_section_desc'] = "لإضافة قسم مساعدة جديد";
$l['add_new_document'] = "إضافة وثيقة جديدة";
$l['add_new_document_desc'] = "لإضافة وثيقة مساعدة جديدة";
$l['edit_section'] = "تعديل قسم";
$l['edit_section_desc'] = "لتعديل قسم المساعدة";
$l['edit_document'] = "تعديل وثيقة";
$l['edit_document_desc'] = "لتعديل وثيقة المساعدة";
$l['manage_help_documents'] = "إدارة وثائق المساعدة";
$l['manage_help_documents_desc'] = "لتعديل, وحذف وإدارة وثائق المساعدة";

$l['title'] = "العنوان";
$l['short_description'] = "وصف موجز";
$l['display_order'] = "ترتيب العرض";
$l['enabled'] = "مفعل ؟";
$l['use_translation'] = "إستخدام ترجمة ؟";
$l['add_section'] = "إضافة قسم";
$l['add_document'] = "إضافة وثيقة";
$l['save_section'] = "حفظ القسم";
$l['save_document'] = "حفظ الوثيقة";
$l['section'] = "قسم";
$l['document'] = "وثيقة";
$l['id'] = "المعرّف ID";
$l['custom_doc_sec'] = "وثيقة/قسم اضافي";
$l['default_doc_sec'] = "وثيقة/قسم إفتراضي";
$l['no_help_documents'] = "لا يوجد حالياً وثائق مساعدة في منتداك";
$l['section_document'] = "قسم / وثيقة";

$l['error_section_missing_name'] = "يجب أن تحدد إسم لهذا القسم";
$l['error_section_missing_description'] = "يجب أن تضع وصف موجز لهذا القسم";
$l['error_section_missing_enabled'] = "يجب أن تحدد نعم أو لا لـ \"مفعل ؟\".";
$l['error_section_missing_translation'] = "يجب أن تحدد نعم أو لا لـ \"إستخدام ترجمة ؟\".";
$l['error_missing_sid'] = "يجب أن تحدد قسم لهذه الوثيقة";
$l['error_document_missing_name'] = "يجب أن تحدد إسم لهذه الوثيقة";
$l['error_document_missing_description'] = "يجب أن تكتب وصف موجز لهذه الوثيقة";
$l['error_document_missing_document'] = "لم تختار أي وثيقة";
$l['error_document_missing_enabled'] = "يجب أن تحدد نعم أو لا لـ \"مفعل ؟\".";
$l['error_document_missing_translation'] = "يجب أن تحدد نعم أو لا لـ \"إستخدام ترجمة ؟\".";
$l['error_invalid_sid'] = "معرّف وثيقة غير صحيحة";
$l['error_missing_section_id'] = "القسم المحدد غير موجود";
$l['error_missing_hid'] = "الوثيقة التي حددتها غير موجودة";

$l['success_help_section_added'] = "تم إضافة قسم المساعدة بنجاح.";
$l['success_help_document_added'] = "تم إضافة وثيقة المساعدة بنجاح.";
$l['success_help_section_updated'] = "تم تحديث قسم المساعدة بنجاح.";
$l['success_help_document_updated'] = "تم تعديل وثيقة المساعدة بنجاح.";
$l['success_section_deleted'] = "تم حذف قسم المساعدة الذي حددته بنجاح.";
$l['success_document_deleted'] = "تم حذف وثيقة المساعدة التي حددتها بنجاح.";

$l['confirm_section_deletion'] = "متأكد من رغبتك في حذف هذا القسم ؟";
$l['confirm_document_deletion'] = "متأكد من رغبتك في حذف هذه الوثيقة ؟";

