<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['spiders_bots'] = "عناكب محركات البحث";
$l['spiders_bots_desc'] = "لإدارة عناكب محركات البحث, التي يتم رصدها تلقائياً بواسطة المنتدى. يمكنك أيضاً أن ترى متى كانت آخر زيارة لها.";
$l['add_new_bot'] = "إضافة عنكبوت جديد.";
$l['add_new_bot_desc'] = "يمكنك إضافة عنكبوت جديد لرصده عند دخول منتداك.";

$l['edit_bot'] = "تعديل عنكبوت.";
$l['edit_bot_desc'] = "لتعديل أحد العناكب التي تم إضافتها مسبقاً.";

$l['bot'] = "العنكبوت";
$l['last_visit'] = "آخر زيارة";
$l['no_bots'] = "لم يتم العثور على أي زيارة من عناكب الزحف في الوقت الحالي.";

$l['name'] = "الإسم";
$l['name_desc'] = "أدخل الإسم الذي تود تعريف هذا العنكبوت به.";
$l['user_agent'] = "الـ User Agent";
$l['user_agent_desc'] = "Enter the string which will be matched against the bots user agent (partial matches are accepted)";
$l['language_str'] = "اللغة";
$l['language_desc'] = "إختر اللغة التي سترى بها عناكب البحث منتداك.";
$l['theme'] = "الإستايل";
$l['theme_desc'] = "أدخل الإستايل الذي سترى بها عناكب البحث منتداك.";
$l['user_group'] = "مجموعة الأعضاء";
$l['user_group_desc'] = "يمكنك إنشاء مجموعة أعضاء جديدة. واعطائها تراخيص مناسبة. ثم وضع عناكب البحث بها. (ملحوظة: ليس مستحسن أن تقوم بتغيير تصاريح مجموعة أعضاء الضيوف الإفتراضية.)";
$l['save_bot'] = "حفظ العنكبوت";
$l['use_board_default'] = "إستخدم الإفتراضيات";

$l['error_invalid_bot'] = "العنكبوت الذي حددته غير موجود.";
$l['error_missing_name'] = "لم تقم بإدخال إسم لهذا العنكبوت.";
$l['error_missing_agent'] = "لم تقم بتحديد الـ User Agent لهذا العنكبوت.";

$l['success_bot_created'] = "تم إنشاء العنكبوت بنجاح.";
$l['success_bot_updated'] = "تم تحديث العنكبوت بنجاح.";
$l['success_bot_deleted'] = "تم حذف العنكبوت بنجاح.";

$l['confirm_bot_deletion'] = "متأكد من رغبتك في حذف هذا العنكبوت ؟";

