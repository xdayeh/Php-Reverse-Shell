<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['home'] = "الرئيسية";

$l['dashboard'] = "الرئيسية";
$l['preferences'] = "الخصائص";
$l['mybb_credits'] = "حقوق MyBB";

$l['add_new_forum'] = "إضافة منتدى جديد";
$l['search_for_users'] = "بحث عن عضو";
$l['themes'] = "الإستايلات";
$l['templates'] = "القوالب";
$l['plugins'] = "الهاكات";
$l['database_backups'] = "النسخ الإحتياطي لقاعدة البيانات";
$l['quick_access'] = "الوصول الفوري";
$l['online_admins'] = "الإداريين المتصلين الآن";
$l['ipaddress'] = "الايبي :";
$l['mybb_documentation'] = "ملف التعريب";

