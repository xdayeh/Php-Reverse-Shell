<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['optimize_database'] = "تحسين قاعدة البيانات";

$l['table_selection'] = "إختيار الجداول";
$l['tables_select_desc'] = "لتحديد الجداول التي يتم تطبيق هذا الإجراء عليها. يمكنك أن تختار عدة جداول عن طريق الضغط مع الإستمرار على زر CTRL وإختيار الجداول.";
$l['select_all'] = "إختر الكل";
$l['deselect_all'] = "إلغاء تحديد الكل";
$l['select_forum_tables'] = "إختر جداول المنتدى";
$l['optimize_selected_tables'] = "تحسين الجداول المحددة";

$l['error_no_tables_selected'] = "لم تقم بتحديد أي جداول لتحسينها.";

$l['success_tables_optimized'] = "تم تحليل وتحسين الجداول التي إخترتها بنجاح.";

