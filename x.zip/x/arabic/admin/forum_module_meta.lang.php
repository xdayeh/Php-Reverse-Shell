<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['forums_and_posts'] = "المنتديات و المشاركات";

$l['forum_management'] = "إدارة المنتديات";
$l['forum_announcements'] = "إعلانات المنتديات";
$l['moderation_queue'] = "المتابعة الإشرافية/الإدراية";
$l['attachments'] = "المرفقات";

$l['can_manage_forums'] = "يمكنه إدارة الاقسام ؟";
$l['can_manage_forum_announcements'] = "يمكنه إدارة إعلانات المنتدى ؟";
$l['can_moderate'] = "يمكنه إدارة الردود, المواضيع, المرفقات ؟";
$l['can_manage_attachments'] = "يمكنه إدارة المرفقات ؟";

