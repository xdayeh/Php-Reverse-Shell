<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['cache'] = "الكاش Cache:";
$l['cache_manager'] = "إدارة الكاش Cache";
$l['cache_manager_description'] = "لإدارة الملفات التخزينية الـ Cache التي يتم إستخدامها لتحسين وتسريع عمل المنتدى";
$l['rebuild_cache'] = "إعادة بناء الكاش Cache";
$l['reload_cache'] = "إعادة تحميل الكاش Cache";
$l['rebuild_reload_all'] = "(اعادة بناء & تحديث الكل)";

$l['error_cannot_rebuild'] = "غير قادر على إعادة بناء الـ Cache";
$l['error_empty_cache'] = "لا يوجد ملفات تخزينية محفوظة";
$l['error_incorrect_cache'] = "الملفات التي حددتها غير صحيحة";
$l['error_no_cache_specified'] = "لم تحدد أي ملفات لعرضها.";

$l['success_cache_rebuilt'] = "تم إعادة بناء الـ Cache بنجاح.";
$l['success_cache_reloaded'] = "تم إعادة تحميل الكاش بنجاح.";

