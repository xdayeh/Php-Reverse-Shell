<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

$l['dashboard'] = "الرئيسية";
$l['dashboard_description'] = "لعرض بعض إحصائيات المنتدى ونظام السيرفر. يمكنك أيضاً إضافة بعد الملاحظات لبقية الإداريين";

$l['mybb_server_stats'] = "إحصائية MyBB وإحصائية السيرفر";
$l['forum_stats'] = "إحصائية المنتدى";
$l['mybb_version'] = "إصدار MyBB";
$l['threads'] = "المواضيع";
$l['new_today'] = "جديد اليوم";
$l['unapproved'] = "غير معتمد";
$l['php_version'] = "إصدار Php";
$l['posts'] = "المشاركات";
$l['sql_engine'] = "محرك قاعدة البيانات Sql";
$l['users'] = "المستخدمين";
$l['registered_users'] = "المسجلين";
$l['active_users'] = "النشطين";
$l['registrations_today'] = "قاموا بالتسجيل اليوم";
$l['awaiting_activation'] = "في إنتظار التفعيل";
$l['server_load'] = "ضغط السيرفر Server Load";
$l['attachments'] = "المرفقات";
$l['used'] = "المستخدم";
$l['reported_posts'] = "مشاركات مبلغ عنها";
$l['unread_reports'] = "تبليغات غير مقروءه";

$l['version_check'] = "الفحص علي تحديثات";
$l['last_update_check_two_weeks'] = "آخر <a href=\"{1}\">MyBB فحص لإصدار</a> كان منذ أكثر من أسبوعين.";
$l['new_version_available'] = "أنت حالياً تستخدم {1}  في حين أن آخر إصدار متوفر هو {2}.";
$l['version_check_description'] = "هنا يمكنك التأكد أنك تعمل علي أحدث نسخه حاليا وتستطيع مشاهده اعلانات الشركة الرسميه";
$l['latest_mybb_announcements'] = "اخر اعلانات الشركة الرسميه";
$l['no_announcements'] = "لا يوجد اعلانات مخزنه <a href=\"index.php?module=home&amp;action=version_check\">فحص التحديثات</a>.";
$l['your_version'] = "اصدارك";
$l['latest_version'] = "اخر اصدار";
$l['update_forum'] = "الرجاء التحديد الي اخر نسخه ماي بي بي <a href=\"http://www.mybbarab.com\" target=\"_blank\">الدعم العربي</a>.";
$l['read_more'] = "اقرا المزيد";

$l['success_up_to_date'] = "تهانينا, انت تعمل حاليا علي اخر اصدار";

$l['error_out_of_date'] = "نسخه منتداك غير محدثه.";
$l['error_communication'] = "يوجد خطأ بالاتصال بالخادم للموقع الرسمي يرجي اعاده المحاوله في وقت اخر.";
$l['error_fetch_news'] = "نجح الاتصال بالموقع الرسمي وجلب احدث الاعلانات .";

$l['news_description'] = "اخر الاخبار من <a href=\"http://www.mybbarab.com/forum-114.html\" target=\"_blank\">الدعم العربي</a>.";

$l['admin_notes_public'] = "هذه الملحوظات هي ملحوظات عامة لكل الإداريين";
$l['admin_notes'] = "ملاحظات الإداريين";
$l['save_notes'] = "حفظ الملاحظات";

$l['success_notes_updated'] = "تم تحديث ملاحظات الإداريين بنجاح";

