<?php
/**
 * MyBB 1.8.5 اللغة العربية لمنتديات
 * Copyright 2015 MyBB Group, All Rights Reserved
 *جميع حقوق التعريب محفوظه لمعهد الدعم العربي www.mybbarab.com
 */

// Tabs
$l['moderation_queue'] = "المتابعة الإدارية";
$l['threads'] = "المواضيع";
$l['threads_desc'] = "لمشاهدة وإعتماد المواضيع التي تنتظر مراجعة الإدارة";
$l['posts'] = "الردود";
$l['posts_desc'] = "لمشاهدة وإعتماد الردود التي تنتظر مراجعة الإدارة";
$l['attachments'] = "المرفقات";
$l['attachments_desc'] = "لمشاهدة وإعتماد المرفقات التي تنتظر مراجعة الإدارة";
$l['threads_awaiting_moderation'] = "مواضيع في إنتظار مراجعة الإدارة";
$l['posts_awaiting_moderation'] = "ردود في إنتظار مراجعة الإدارة";
$l['attachments_awaiting_moderation'] = "مرفقات في إنتظار مراجعة الإدارة";

// Errors
$l['error_no_posts'] = "لا يوجد حالياً مشاركات في إنتظار مراجعة الإدارة";
$l['error_no_attachments'] = "لا يوجد حالياً مرفقات في إنتظار مراجعة الإدارة";
$l['error_no_threads'] = "لا يوجد حالياً ردود, مواضيع, مرفقات في إنتظار مراجعة الإدارة";

// Success
$l['success_threads'] = "تم إدارة المواضيع التي حددتها بنجاح";
$l['success_posts'] = "تم إدارة الردود التي حددتها بنجاح.";
$l['success_attachments'] = "تم إدارة المرفقات التي حددتها بنجاح.";

// Pages
$l['subject'] = "العنوان";
$l['author'] = "الكاتب";
$l['posted'] = "كتبت";
$l['ignore'] = "تجاهل";
$l['approve'] = "إعتماد";
$l['forum'] = "المنتدى:";
$l['thread'] = "الموضوع:";
$l['post'] = "الرد:";
$l['re'] = "الرد:";
$l['filename'] = "إسم الملف";
$l['uploadedby'] = "رفعت بواسطة";
$l['controls'] = "التحكم";

// Buttons
$l['mark_as_ignored'] = "تحديد الكل للتجاهل";
$l['mark_as_deleted'] = "تحديد الكل للحذف";
$l['mark_as_approved'] = "تحديد الكل للإعتماد";
$l['perform_action'] = "تنفيذ الإجراء";

