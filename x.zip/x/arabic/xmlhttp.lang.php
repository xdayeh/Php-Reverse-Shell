<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 */



$l['no_new_subject'] = 'لم تدخل عنوان جديد';
$l['post_moderation'] = 'مشاركتك في إنتظار مراجعة الإدارة';
$l['thread_moderation'] = 'موضوعك الان تحت الرقابه.';
$l['post_doesnt_exist'] = 'المشاركة التي حددتها غير موجودة .';
$l['thread_doesnt_exist'] = 'الموضوع الذي حددته غير موجود';
$l['thread_closed_edit_subjects'] = 'موضوع مغلق. لا يمكنك تعديل عنوانه';
$l['no_permission_edit_subject'] = 'ليس لديك الصلاحيات لتعديل عنوان هذا الموضوع .';
$l['thread_closed_edit_message'] = 'موضوع مغلق. لا يمكنك تعديل أي شيء به';
$l['no_permission_edit_post'] = 'ليس لديك الصلاحيات للقيام بهذا التعديل';
$l['edit_time_limit'] = 'يمكنك فقط تعديل المشاركة خلال {1} دقائق من بعد كتابتها .';
$l['postbit_edited'] = 'آخر تعديل لهذه المشاركة في: {1} بواسطة';
$l['postbit_editreason'] = 'تعديل السبب';
$l['save_changes'] = 'حفظ التعديلات';
$l['cancel_edit'] = 'إلغاء التعديل';
$l['answer_valid_not_exists'] = 'السؤال الذي تجاوب عليه ليس وجود له';
$l['captcha_not_exists'] = 'صورة الكود التي تحاول تحديثها غير موجودة .';
$l['captcha_valid_not_exists'] = 'صورة الكود التي تحاول التأكد من صحتها غير موجودة .';
$l['captcha_does_not_match'] = 'كود التأكيد الذي أدخلته غير صحيح. من فضلك أعد كتابة الكود تماماً كما هو موضح في الصورة .';
$l['captcha_matches'] = 'كود الصورة الذي كتبته يبدو صحيحاً .';
$l['answer_does_not_match'] = 'الاجابه التي ادخلتها غير صحيحه.';
$l['banned_username'] = 'إسم المستخدم الذي أدخلته ممنوع إستخدامه بواسطة الإدارة';
$l['banned_characters_username'] = 'إسم المستخدم الذي أدخلته يحتوي على رمز أو أكثر من الرموز الممنوع إستخدامها في أسماء العضوية';
$l['complex_password_fails'] = 'كلمة المرور يجب أن تكون أصعب من ذلك';
$l['username_taken'] = '{1} مسجل بالفعل بواسطة عضو آخر';
$l['username_available'] = '{1} متوفر';
$l['invalid_username'] = '{1} ليس إسم مستخدم في المنتدى';
$l['valid_username'] = '{1} دعوة صحيحة .';
$l['buddylist_error'] = 'لا يبدوا أنك لديك أي أعضاء في قائمة الأصدقاء. من فضلك حاول إضافة أعضاء لقائمة أصدقائك قبل إستخدام هذا .';
$l['close'] = 'إغلاق';
$l['select_buddies'] = 'إختر الأصدقاء';
$l['select_buddies_desc'] = 'لإضافة صديق أو أكثر, قم بالإختيار أدناه ثم إضغط موافق .';
$l['selected_recipients'] = 'إختر المستلمين';
$l['ok'] = 'موافق';
$l['cancel'] = 'إلغاء';
$l['online'] = 'متصل';
$l['offline'] = 'غير متصل';
$l['edited_post'] = 'مشاركة تم تعديلها';
$l['usergroup'] = 'مجموعه العضو';
